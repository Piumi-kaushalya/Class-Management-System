﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Add_Ol_result
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.bntsave = New System.Windows.Forms.Button()
        Me.txtyear = New System.Windows.Forms.TextBox()
        Me.cmbattemt = New System.Windows.Forms.ComboBox()
        Me.bntreset = New System.Windows.Forms.Button()
        Me.txtstuid = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.bntback = New System.Windows.Forms.Button()
        Me.txtresult6 = New System.Windows.Forms.TextBox()
        Me.txtresult5 = New System.Windows.Forms.TextBox()
        Me.txtresult4 = New System.Windows.Forms.TextBox()
        Me.txtresult1 = New System.Windows.Forms.TextBox()
        Me.txtresult2 = New System.Windows.Forms.TextBox()
        Me.txtresult3 = New System.Windows.Forms.TextBox()
        Me.txtsub6 = New System.Windows.Forms.TextBox()
        Me.txtsub5 = New System.Windows.Forms.TextBox()
        Me.txtsub4 = New System.Windows.Forms.TextBox()
        Me.txtsub1 = New System.Windows.Forms.TextBox()
        Me.txtsub2 = New System.Windows.Forms.TextBox()
        Me.txtsub3 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(256, 24)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(408, 51)
        Me.Label1.TabIndex = 46
        Me.Label1.Text = "Add Ordinary Level"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(72, 152)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(134, 29)
        Me.Label3.TabIndex = 47
        Me.Label3.Text = "Student ID"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(576, 152)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(101, 29)
        Me.Label4.TabIndex = 48
        Me.Label4.Text = "Attempt"
        '
        'bntsave
        '
        Me.bntsave.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.bntsave.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntsave.ForeColor = System.Drawing.Color.White
        Me.bntsave.Location = New System.Drawing.Point(176, 648)
        Me.bntsave.Margin = New System.Windows.Forms.Padding(4)
        Me.bntsave.Name = "bntsave"
        Me.bntsave.Size = New System.Drawing.Size(192, 56)
        Me.bntsave.TabIndex = 52
        Me.bntsave.Text = "Save"
        Me.bntsave.UseVisualStyleBackColor = False
        '
        'txtyear
        '
        Me.txtyear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtyear.Location = New System.Drawing.Point(224, 210)
        Me.txtyear.Margin = New System.Windows.Forms.Padding(4)
        Me.txtyear.Name = "txtyear"
        Me.txtyear.Size = New System.Drawing.Size(248, 30)
        Me.txtyear.TabIndex = 2
        '
        'cmbattemt
        '
        Me.cmbattemt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbattemt.FormattingEnabled = True
        Me.cmbattemt.Items.AddRange(New Object() {"1", "2"})
        Me.cmbattemt.Location = New System.Drawing.Point(720, 152)
        Me.cmbattemt.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbattemt.Name = "cmbattemt"
        Me.cmbattemt.Size = New System.Drawing.Size(132, 33)
        Me.cmbattemt.TabIndex = 8
        '
        'bntreset
        '
        Me.bntreset.BackColor = System.Drawing.Color.Gray
        Me.bntreset.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntreset.ForeColor = System.Drawing.Color.White
        Me.bntreset.Location = New System.Drawing.Point(416, 648)
        Me.bntreset.Margin = New System.Windows.Forms.Padding(4)
        Me.bntreset.Name = "bntreset"
        Me.bntreset.Size = New System.Drawing.Size(192, 56)
        Me.bntreset.TabIndex = 61
        Me.bntreset.Text = "Reset"
        Me.bntreset.UseVisualStyleBackColor = False
        '
        'txtstuid
        '
        Me.txtstuid.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstuid.Location = New System.Drawing.Point(224, 151)
        Me.txtstuid.Margin = New System.Windows.Forms.Padding(4)
        Me.txtstuid.Name = "txtstuid"
        Me.txtstuid.Size = New System.Drawing.Size(248, 30)
        Me.txtstuid.TabIndex = 1
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(72, 208)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(68, 29)
        Me.Label14.TabIndex = 80
        Me.Label14.Text = "Year"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.bntback)
        Me.Panel1.Controls.Add(Me.txtresult6)
        Me.Panel1.Controls.Add(Me.txtresult5)
        Me.Panel1.Controls.Add(Me.txtresult4)
        Me.Panel1.Controls.Add(Me.txtresult1)
        Me.Panel1.Controls.Add(Me.txtresult2)
        Me.Panel1.Controls.Add(Me.txtresult3)
        Me.Panel1.Controls.Add(Me.txtsub6)
        Me.Panel1.Controls.Add(Me.txtsub5)
        Me.Panel1.Controls.Add(Me.txtsub4)
        Me.Panel1.Controls.Add(Me.txtsub1)
        Me.Panel1.Controls.Add(Me.txtsub2)
        Me.Panel1.Controls.Add(Me.txtsub3)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.txtstuid)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.bntreset)
        Me.Panel1.Controls.Add(Me.cmbattemt)
        Me.Panel1.Controls.Add(Me.txtyear)
        Me.Panel1.Controls.Add(Me.bntsave)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Location = New System.Drawing.Point(24, 24)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1004, 752)
        Me.Panel1.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1008, 88)
        Me.Panel2.TabIndex = 96
        '
        'bntback
        '
        Me.bntback.BackColor = System.Drawing.Color.LightBlue
        Me.bntback.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntback.ForeColor = System.Drawing.Color.Black
        Me.bntback.Location = New System.Drawing.Point(656, 648)
        Me.bntback.Margin = New System.Windows.Forms.Padding(4)
        Me.bntback.Name = "bntback"
        Me.bntback.Size = New System.Drawing.Size(192, 56)
        Me.bntback.TabIndex = 95
        Me.bntback.Text = "Back"
        Me.bntback.UseVisualStyleBackColor = False
        '
        'txtresult6
        '
        Me.txtresult6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtresult6.Location = New System.Drawing.Point(736, 560)
        Me.txtresult6.Margin = New System.Windows.Forms.Padding(4)
        Me.txtresult6.Name = "txtresult6"
        Me.txtresult6.Size = New System.Drawing.Size(132, 30)
        Me.txtresult6.TabIndex = 14
        '
        'txtresult5
        '
        Me.txtresult5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtresult5.Location = New System.Drawing.Point(736, 504)
        Me.txtresult5.Margin = New System.Windows.Forms.Padding(4)
        Me.txtresult5.Name = "txtresult5"
        Me.txtresult5.Size = New System.Drawing.Size(132, 30)
        Me.txtresult5.TabIndex = 13
        '
        'txtresult4
        '
        Me.txtresult4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtresult4.Location = New System.Drawing.Point(736, 448)
        Me.txtresult4.Margin = New System.Windows.Forms.Padding(4)
        Me.txtresult4.Name = "txtresult4"
        Me.txtresult4.Size = New System.Drawing.Size(132, 30)
        Me.txtresult4.TabIndex = 12
        '
        'txtresult1
        '
        Me.txtresult1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtresult1.Location = New System.Drawing.Point(736, 280)
        Me.txtresult1.Margin = New System.Windows.Forms.Padding(4)
        Me.txtresult1.Name = "txtresult1"
        Me.txtresult1.Size = New System.Drawing.Size(132, 30)
        Me.txtresult1.TabIndex = 9
        '
        'txtresult2
        '
        Me.txtresult2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtresult2.Location = New System.Drawing.Point(736, 336)
        Me.txtresult2.Margin = New System.Windows.Forms.Padding(4)
        Me.txtresult2.Name = "txtresult2"
        Me.txtresult2.Size = New System.Drawing.Size(132, 30)
        Me.txtresult2.TabIndex = 10
        '
        'txtresult3
        '
        Me.txtresult3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtresult3.Location = New System.Drawing.Point(736, 392)
        Me.txtresult3.Margin = New System.Windows.Forms.Padding(4)
        Me.txtresult3.Name = "txtresult3"
        Me.txtresult3.Size = New System.Drawing.Size(132, 30)
        Me.txtresult3.TabIndex = 11
        '
        'txtsub6
        '
        Me.txtsub6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsub6.Location = New System.Drawing.Point(224, 564)
        Me.txtsub6.Margin = New System.Windows.Forms.Padding(4)
        Me.txtsub6.Name = "txtsub6"
        Me.txtsub6.Size = New System.Drawing.Size(224, 30)
        Me.txtsub6.TabIndex = 8
        '
        'txtsub5
        '
        Me.txtsub5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsub5.Location = New System.Drawing.Point(224, 505)
        Me.txtsub5.Margin = New System.Windows.Forms.Padding(4)
        Me.txtsub5.Name = "txtsub5"
        Me.txtsub5.Size = New System.Drawing.Size(224, 30)
        Me.txtsub5.TabIndex = 7
        '
        'txtsub4
        '
        Me.txtsub4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsub4.Location = New System.Drawing.Point(224, 446)
        Me.txtsub4.Margin = New System.Windows.Forms.Padding(4)
        Me.txtsub4.Name = "txtsub4"
        Me.txtsub4.Size = New System.Drawing.Size(224, 30)
        Me.txtsub4.TabIndex = 6
        '
        'txtsub1
        '
        Me.txtsub1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsub1.Location = New System.Drawing.Point(224, 269)
        Me.txtsub1.Margin = New System.Windows.Forms.Padding(4)
        Me.txtsub1.Name = "txtsub1"
        Me.txtsub1.Size = New System.Drawing.Size(224, 30)
        Me.txtsub1.TabIndex = 3
        '
        'txtsub2
        '
        Me.txtsub2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsub2.Location = New System.Drawing.Point(224, 328)
        Me.txtsub2.Margin = New System.Windows.Forms.Padding(4)
        Me.txtsub2.Name = "txtsub2"
        Me.txtsub2.Size = New System.Drawing.Size(224, 30)
        Me.txtsub2.TabIndex = 4
        '
        'txtsub3
        '
        Me.txtsub3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsub3.Location = New System.Drawing.Point(224, 387)
        Me.txtsub3.Margin = New System.Windows.Forms.Padding(4)
        Me.txtsub3.Name = "txtsub3"
        Me.txtsub3.Size = New System.Drawing.Size(224, 30)
        Me.txtsub3.TabIndex = 5
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(48, 536)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(0, 29)
        Me.Label7.TabIndex = 69
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(72, 280)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(101, 29)
        Me.Label10.TabIndex = 65
        Me.Label10.Text = "Subject"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(72, 392)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(101, 29)
        Me.Label9.TabIndex = 64
        Me.Label9.Text = "Subject"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(72, 560)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(101, 29)
        Me.Label8.TabIndex = 63
        Me.Label8.Text = "Subject"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(72, 448)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(101, 29)
        Me.Label5.TabIndex = 51
        Me.Label5.Text = "Subject"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(72, 504)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(101, 29)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "Subject"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(72, 336)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(101, 29)
        Me.Label6.TabIndex = 49
        Me.Label6.Text = "Subject"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(584, 448)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(87, 29)
        Me.Label11.TabIndex = 97
        Me.Label11.Text = "Result"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(584, 504)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(87, 29)
        Me.Label12.TabIndex = 98
        Me.Label12.Text = "Result"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(584, 336)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(87, 29)
        Me.Label13.TabIndex = 99
        Me.Label13.Text = "Result"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(584, 392)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(87, 29)
        Me.Label15.TabIndex = 100
        Me.Label15.Text = "Result"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(584, 283)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(87, 29)
        Me.Label16.TabIndex = 101
        Me.Label16.Text = "Result"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(584, 560)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(87, 29)
        Me.Label17.TabIndex = 102
        Me.Label17.Text = "Result"
        '
        'Add_Ol_result
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumAquamarine
        Me.ClientSize = New System.Drawing.Size(1052, 795)
        Me.Controls.Add(Me.Panel1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Add_Ol_result"
        Me.Text = "Add Ordinary Level"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents bntsave As Button
    Friend WithEvents txtyear As TextBox
    Friend WithEvents cmbattemt As ComboBox
    Friend WithEvents bntreset As Button
    Friend WithEvents txtstuid As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents txtresult6 As TextBox
    Friend WithEvents txtresult5 As TextBox
    Friend WithEvents txtresult4 As TextBox
    Friend WithEvents txtresult1 As TextBox
    Friend WithEvents txtresult2 As TextBox
    Friend WithEvents txtresult3 As TextBox
    Friend WithEvents txtsub6 As TextBox
    Friend WithEvents txtsub5 As TextBox
    Friend WithEvents txtsub4 As TextBox
    Friend WithEvents txtsub1 As TextBox
    Friend WithEvents txtsub2 As TextBox
    Friend WithEvents txtsub3 As TextBox
    Friend WithEvents bntback As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label17 As Label
End Class
