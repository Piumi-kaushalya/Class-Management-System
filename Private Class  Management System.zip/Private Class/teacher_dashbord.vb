﻿Public Class teacher_dashbord
    Private Sub bntst_attendence_Click(sender As Object, e As EventArgs) 
        student_attendance.Show()
        Me.Hide()
    End Sub

    Private Sub bntresult_Click(sender As Object, e As EventArgs) 
        Select_Result.Show()
        Me.Hide()
    End Sub

    Private Sub bntrepots_Click(sender As Object, e As EventArgs) 
        view_Reports.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) 
        login.Show()
        Me.Hide()
    End Sub
End Class