﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Add_AL_Result
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtresuilt3 = New System.Windows.Forms.TextBox()
        Me.txtresult2 = New System.Windows.Forms.TextBox()
        Me.cmbsub3 = New System.Windows.Forms.ComboBox()
        Me.cmbsub2 = New System.Windows.Forms.ComboBox()
        Me.txtsid = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.bntresset = New System.Windows.Forms.Button()
        Me.cmbsub1 = New System.Windows.Forms.ComboBox()
        Me.Cmbattemp = New System.Windows.Forms.ComboBox()
        Me.txtyear = New System.Windows.Forms.TextBox()
        Me.txtresult1 = New System.Windows.Forms.TextBox()
        Me.bntsave = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.txtresuilt3)
        Me.Panel1.Controls.Add(Me.txtresult2)
        Me.Panel1.Controls.Add(Me.cmbsub3)
        Me.Panel1.Controls.Add(Me.cmbsub2)
        Me.Panel1.Controls.Add(Me.txtsid)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.bntresset)
        Me.Panel1.Controls.Add(Me.cmbsub1)
        Me.Panel1.Controls.Add(Me.Cmbattemp)
        Me.Panel1.Controls.Add(Me.txtyear)
        Me.Panel1.Controls.Add(Me.txtresult1)
        Me.Panel1.Controls.Add(Me.bntsave)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Location = New System.Drawing.Point(24, 24)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1040, 656)
        Me.Panel1.TabIndex = 0
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.LightBlue
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.Black
        Me.Button2.Location = New System.Drawing.Point(650, 544)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(192, 56)
        Me.Button2.TabIndex = 67
        Me.Button2.Text = "Back"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(704, 384)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(101, 29)
        Me.Label10.TabIndex = 38
        Me.Label10.Text = "Result2"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(704, 444)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(101, 29)
        Me.Label9.TabIndex = 37
        Me.Label9.Text = "Result3"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(704, 324)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(101, 29)
        Me.Label8.TabIndex = 36
        Me.Label8.Text = "Result1"
        '
        'txtresuilt3
        '
        Me.txtresuilt3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtresuilt3.Location = New System.Drawing.Point(848, 440)
        Me.txtresuilt3.Margin = New System.Windows.Forms.Padding(4)
        Me.txtresuilt3.Name = "txtresuilt3"
        Me.txtresuilt3.Size = New System.Drawing.Size(132, 29)
        Me.txtresuilt3.TabIndex = 35
        '
        'txtresult2
        '
        Me.txtresult2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtresult2.Location = New System.Drawing.Point(848, 384)
        Me.txtresult2.Margin = New System.Windows.Forms.Padding(4)
        Me.txtresult2.Name = "txtresult2"
        Me.txtresult2.Size = New System.Drawing.Size(132, 29)
        Me.txtresult2.TabIndex = 34
        '
        'cmbsub3
        '
        Me.cmbsub3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbsub3.FormattingEnabled = True
        Me.cmbsub3.Location = New System.Drawing.Point(280, 448)
        Me.cmbsub3.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbsub3.Name = "cmbsub3"
        Me.cmbsub3.Size = New System.Drawing.Size(360, 32)
        Me.cmbsub3.TabIndex = 6
        '
        'cmbsub2
        '
        Me.cmbsub2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbsub2.FormattingEnabled = True
        Me.cmbsub2.Location = New System.Drawing.Point(280, 384)
        Me.cmbsub2.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbsub2.Name = "cmbsub2"
        Me.cmbsub2.Size = New System.Drawing.Size(360, 32)
        Me.cmbsub2.TabIndex = 5
        '
        'txtsid
        '
        Me.txtsid.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsid.Location = New System.Drawing.Point(241, 117)
        Me.txtsid.Margin = New System.Windows.Forms.Padding(4)
        Me.txtsid.Name = "txtsid"
        Me.txtsid.Size = New System.Drawing.Size(179, 29)
        Me.txtsid.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(72, 120)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(134, 29)
        Me.Label7.TabIndex = 30
        Me.Label7.Text = "Student ID"
        '
        'bntresset
        '
        Me.bntresset.BackColor = System.Drawing.Color.Silver
        Me.bntresset.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntresset.ForeColor = System.Drawing.Color.White
        Me.bntresset.Location = New System.Drawing.Point(426, 544)
        Me.bntresset.Margin = New System.Windows.Forms.Padding(4)
        Me.bntresset.Name = "bntresset"
        Me.bntresset.Size = New System.Drawing.Size(192, 56)
        Me.bntresset.TabIndex = 29
        Me.bntresset.Text = "Reset"
        Me.bntresset.UseVisualStyleBackColor = False
        '
        'cmbsub1
        '
        Me.cmbsub1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbsub1.FormattingEnabled = True
        Me.cmbsub1.Location = New System.Drawing.Point(280, 320)
        Me.cmbsub1.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbsub1.Name = "cmbsub1"
        Me.cmbsub1.Size = New System.Drawing.Size(360, 32)
        Me.cmbsub1.TabIndex = 4
        '
        'Cmbattemp
        '
        Me.Cmbattemp.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmbattemp.FormattingEnabled = True
        Me.Cmbattemp.Items.AddRange(New Object() {"1 St attempt", "2 St attempt", "3 St attempt"})
        Me.Cmbattemp.Location = New System.Drawing.Point(241, 239)
        Me.Cmbattemp.Margin = New System.Windows.Forms.Padding(4)
        Me.Cmbattemp.Name = "Cmbattemp"
        Me.Cmbattemp.Size = New System.Drawing.Size(184, 32)
        Me.Cmbattemp.TabIndex = 25
        '
        'txtyear
        '
        Me.txtyear.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtyear.Location = New System.Drawing.Point(241, 178)
        Me.txtyear.Margin = New System.Windows.Forms.Padding(4)
        Me.txtyear.Name = "txtyear"
        Me.txtyear.Size = New System.Drawing.Size(183, 29)
        Me.txtyear.TabIndex = 2
        '
        'txtresult1
        '
        Me.txtresult1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtresult1.Location = New System.Drawing.Point(848, 328)
        Me.txtresult1.Margin = New System.Windows.Forms.Padding(4)
        Me.txtresult1.Name = "txtresult1"
        Me.txtresult1.Size = New System.Drawing.Size(132, 29)
        Me.txtresult1.TabIndex = 21
        '
        'bntsave
        '
        Me.bntsave.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.bntsave.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntsave.ForeColor = System.Drawing.Color.White
        Me.bntsave.Location = New System.Drawing.Point(202, 544)
        Me.bntsave.Margin = New System.Windows.Forms.Padding(4)
        Me.bntsave.Name = "bntsave"
        Me.bntsave.Size = New System.Drawing.Size(192, 56)
        Me.bntsave.TabIndex = 19
        Me.bntsave.Text = "Save"
        Me.bntsave.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(76, 389)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(136, 29)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Subject 02"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(76, 450)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(136, 29)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Subject 03"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(76, 328)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(136, 29)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Subject 01"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(80, 240)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(101, 29)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Attempt"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(80, 180)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 29)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Year"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(216, 16)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(594, 54)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Add Advance Result Level"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1040, 72)
        Me.Panel3.TabIndex = 69
        '
        'Add_AL_Result
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumAquamarine
        Me.ClientSize = New System.Drawing.Size(1089, 702)
        Me.Controls.Add(Me.Panel1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Add_AL_Result"
        Me.Text = "Add Advance Level"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents bntsave As Button
    Friend WithEvents txtresult1 As TextBox
    Friend WithEvents cmbsub1 As ComboBox
    Friend WithEvents Cmbattemp As ComboBox
    Friend WithEvents txtyear As TextBox
    Friend WithEvents bntresset As Button
    Friend WithEvents txtsid As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtresuilt3 As TextBox
    Friend WithEvents txtresult2 As TextBox
    Friend WithEvents cmbsub3 As ComboBox
    Friend WithEvents cmbsub2 As ComboBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents Button2 As Button
    Friend WithEvents Panel3 As Panel
End Class
