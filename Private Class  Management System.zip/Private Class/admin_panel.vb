﻿Imports System.Text.RegularExpressions
Public Class admin
    Private Sub Teacher_sallery_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub



    Private Sub txtsid_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtsid_KeyPress(sender As Object, e As KeyPressEventArgs)
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        manager_registration.Show()
        Me.Hide()

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        login.Show()
        Me.Hide()

    End Sub
End Class