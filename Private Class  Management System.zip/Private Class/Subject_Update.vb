﻿Imports MySql.Data.MySqlClient
Public Class Update_subject
    Private Sub Bntrest_Click(sender As Object, e As EventArgs) Handles Bntrest.Click
        If Open_db() Then
            Dim querystr As String
            querystr = "SELECT * FROM `subjects` WHERE Subject_Id = '" & txtsubid.Text & "'"
            Dim command1 As New MySqlCommand(querystr, conn)
            Dim reader As MySqlDataReader
            Dim subject_name As String
            Dim level As String


            reader = command1.ExecuteReader
            reader.Read()
            subject_name = reader.GetString(1)
            level = reader.GetString(2)


            reader.Close()


            txtsname.Text = subject_name
            txtlevel.Text = level


        End If
    End Sub

    Private Sub Btnsave_Click(sender As Object, e As EventArgs) Handles Btnsave.Click
        Dim subject_id As Integer
        Dim result As Boolean
        Dim queryupdate, subject_name, level As String

        subject_id = txtsubid.Text
        subject_name = txtsname.Text
        level = txtlevel.Text
        If Open_db() Then
            queryupdate = "UPDATE `subjects` SET `Subject_Id`=@subid,`Subject_Name`=@subname,`Level`=@level WHERE `Subject_Id`=@subid "
            Dim command As New MySqlCommand(queryupdate, conn)
            command.Parameters.Add("@subid", MySqlDbType.Int32).Value = subject_id
            command.Parameters.Add("@subname", MySqlDbType.VarChar).Value = subject_name
            command.Parameters.Add("@level", MySqlDbType.VarChar).Value = level

            Try
                result = command.ExecuteNonQuery()
                If result Then
                    MsgBox("successfully updated")
                    txtsubid.Text = ""
                    txtsname.Text = ""
                    txtlevel.Text = ""


                Else
                    MsgBox("Not Added")


                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub Update_subject_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class