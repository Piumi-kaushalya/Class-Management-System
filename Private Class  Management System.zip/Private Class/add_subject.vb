﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class add_subject
    Private Sub Btnsave_Click(sender As Object, e As EventArgs) Handles Btnsave.Click
        Dim Subject_Name, Level, querystr As String
        Dim result As Boolean


        Subject_Name = Txtsubname.Text
        Level = Cmbgrade.Text
        If empty(Subject_Name) Or empty(Level) Then
            MsgBox("All Filds are Required")

        Else

            If Open_db() Then

                querystr = "INSERT INTO `subjects`(`Subject_Name`, `Level`) VALUES (@SN, @LE)"
                Dim command As New MySqlCommand(querystr, conn)

                command.Parameters.Add("@SN", MySqlDbType.VarChar).Value = Subject_Name
                command.Parameters.Add("@LE", MySqlDbType.VarChar).Value = Level

                Try
                    result = command.ExecuteNonQuery()
                    If result Then

                        MsgBox("New subject added")
                    Else
                        MsgBox("Not Added")
                    End If

                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
            Else
                MsgBox("connection error")

            End If
        End If
    End Sub

    Private Sub add_subject_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Registration_select.Show()
        Me.Hide()

    End Sub

    Private Sub Bntrest_Click(sender As Object, e As EventArgs) Handles Bntrest.Click
        Txtsubname.Text = ""
    End Sub

    Private Sub Txtsubname_TextChanged(sender As Object, e As EventArgs) Handles Txtsubname.TextChanged

    End Sub

    Private Sub Txtsubname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txtsubname.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub
End Class