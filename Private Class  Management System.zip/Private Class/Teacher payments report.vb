﻿Public Class Teacher_payments_report
    Private Sub View_Click(sender As Object, e As EventArgs) Handles View.Click

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Manager_Reports.Show()
        Me.Hide()

    End Sub
End Class