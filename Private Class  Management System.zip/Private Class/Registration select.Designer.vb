﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Registration_select
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.bntcr = New System.Windows.Forms.Button()
        Me.bntpi = New System.Windows.Forms.Button()
        Me.bnttr = New System.Windows.Forms.Button()
        Me.bntstr = New System.Windows.Forms.Button()
        Me.bntadds = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.bntstaddclass = New System.Windows.Forms.Button()
        Me.bntback = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'bntcr
        '
        Me.bntcr.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntcr.FlatAppearance.BorderSize = 5
        Me.bntcr.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntcr.Location = New System.Drawing.Point(208, 376)
        Me.bntcr.Name = "bntcr"
        Me.bntcr.Size = New System.Drawing.Size(352, 48)
        Me.bntcr.TabIndex = 2
        Me.bntcr.Text = "Class Registration" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.bntcr.UseVisualStyleBackColor = False
        '
        'bntpi
        '
        Me.bntpi.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntpi.FlatAppearance.BorderSize = 5
        Me.bntpi.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntpi.Location = New System.Drawing.Point(208, 56)
        Me.bntpi.Name = "bntpi"
        Me.bntpi.Size = New System.Drawing.Size(352, 48)
        Me.bntpi.TabIndex = 3
        Me.bntpi.Text = "Parent information"
        Me.bntpi.UseVisualStyleBackColor = False
        '
        'bnttr
        '
        Me.bnttr.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bnttr.FlatAppearance.BorderSize = 5
        Me.bnttr.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bnttr.Location = New System.Drawing.Point(208, 296)
        Me.bnttr.Name = "bnttr"
        Me.bnttr.Size = New System.Drawing.Size(352, 48)
        Me.bnttr.TabIndex = 4
        Me.bnttr.Text = "Teacher Registration"
        Me.bnttr.UseVisualStyleBackColor = False
        '
        'bntstr
        '
        Me.bntstr.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntstr.FlatAppearance.BorderSize = 5
        Me.bntstr.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntstr.Location = New System.Drawing.Point(208, 136)
        Me.bntstr.Name = "bntstr"
        Me.bntstr.Size = New System.Drawing.Size(352, 48)
        Me.bntstr.TabIndex = 5
        Me.bntstr.Text = "Student Registration"
        Me.bntstr.UseVisualStyleBackColor = False
        '
        'bntadds
        '
        Me.bntadds.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntadds.FlatAppearance.BorderSize = 5
        Me.bntadds.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntadds.Location = New System.Drawing.Point(208, 216)
        Me.bntadds.Name = "bntadds"
        Me.bntadds.Size = New System.Drawing.Size(352, 48)
        Me.bntadds.TabIndex = 6
        Me.bntadds.Text = "Add Subject"
        Me.bntadds.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(32, 32)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(784, 56)
        Me.Panel1.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(184, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(359, 44)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Registration Select"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.bntstaddclass)
        Me.Panel2.Controls.Add(Me.bntback)
        Me.Panel2.Controls.Add(Me.bntpi)
        Me.Panel2.Controls.Add(Me.bntcr)
        Me.Panel2.Controls.Add(Me.bnttr)
        Me.Panel2.Controls.Add(Me.bntadds)
        Me.Panel2.Controls.Add(Me.bntstr)
        Me.Panel2.Location = New System.Drawing.Point(32, 88)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(784, 608)
        Me.Panel2.TabIndex = 8
        '
        'bntstaddclass
        '
        Me.bntstaddclass.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntstaddclass.FlatAppearance.BorderSize = 5
        Me.bntstaddclass.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntstaddclass.Location = New System.Drawing.Point(208, 464)
        Me.bntstaddclass.Name = "bntstaddclass"
        Me.bntstaddclass.Size = New System.Drawing.Size(352, 48)
        Me.bntstaddclass.TabIndex = 70
        Me.bntstaddclass.Text = "Student Enter Class"
        Me.bntstaddclass.UseVisualStyleBackColor = False
        '
        'bntback
        '
        Me.bntback.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.bntback.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntback.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.bntback.Location = New System.Drawing.Point(368, 536)
        Me.bntback.Margin = New System.Windows.Forms.Padding(4)
        Me.bntback.Name = "bntback"
        Me.bntback.Size = New System.Drawing.Size(192, 56)
        Me.bntback.TabIndex = 69
        Me.bntback.Text = "Back"
        Me.bntback.UseVisualStyleBackColor = False
        '
        'Registration_select
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumAquamarine
        Me.ClientSize = New System.Drawing.Size(851, 721)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Name = "Registration_select"
        Me.Text = "Registration_select"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents bntcr As Button
    Friend WithEvents bntpi As Button
    Friend WithEvents bnttr As Button
    Friend WithEvents bntstr As Button
    Friend WithEvents bntadds As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents bntback As Button
    Friend WithEvents bntstaddclass As Button
End Class
