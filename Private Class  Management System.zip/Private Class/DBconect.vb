﻿Imports MySql.Data.MySqlClient
Module DBconect

    Public conn As New MySqlConnection
    Dim resut As Boolean

    Public Function Open_db()
        Try


            If conn.State = ConnectionState.Closed Then
                conn.ConnectionString = "datasource=localhost;username=root;password=;database=private_class"

                conn.Open()
                resut = conn.State

            End If

        Catch ex As Exception
            MsgBox("connection error")

        End Try
        Return resut
    End Function


End Module
