﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class Income
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles bntenter.Click
        Dim fromdateN, toDateN As Date
        Dim qury As String

        If Open_db() Then
            Dim da As New MySqlDataAdapter
            'Dim Command As MySqlCommand
            'Dim datareader As MySqlDataReader
            Dim table As New DataTable

            fromdateN = fromdate.Value.Date
            toDateN = todate.Value.Date

            'qury = "SELECT * FROM student_fees WHERE (Payment_Date BETWEEN '" & fromdate & "' AND '" & toDate & "') AND (Class_Name='" & txtclassid.Text & "')"
            qury = "SELECT * FROM student_fees WHERE ((Class_Name='" & txtclassid.Text & "') AND (Payment_Date BETWEEN '" & Format(fromdateN, "yyyy-MM-dd") & "' AND '" & Format(toDateN, "yyyy-MM-dd") & "'))"
            da.SelectCommand = New MySqlCommand(qury, conn)

            da.Fill(table)
            'DataGridView1.DataSource = table

            'Command.CommandText = qury
            'Command.Connection = conn
            'Command.Parameters.AddWithValue("@FNAM", Cmbstudentname.SelectedValue)


            'datareader = Command.ExecuteReader
            'table.Load(datareader)

            DataGridView1.DataSource = table
            'MsgBox(fromdateN)

            DataGridView1.AllowUserToAddRows = False
            DataGridView1.AllowUserToAddRows = False
        End If
    End Sub

    Private Sub View_Click(sender As Object, e As EventArgs) Handles View.Click
        Finance.Show()
        Me.Show()
    End Sub

    Private Sub txtclassid_TextChanged(sender As Object, e As EventArgs) Handles txtclassid.TextChanged

    End Sub

    Private Sub txtclassid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtclassid.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Income_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class