﻿Imports MySql.Data.MySqlClient
Public Class Report_parents_details
    Dim command As New MySqlCommand
    Dim datareader As MySqlDataReader
    Dim querystr As String
    Dim table As New DataTable

    Private Sub Report_parents_details_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Open_db() Then


            querystr = "SELECT `Parents_Id`, `NIC_No`, `Occupation`, `Phone_No`, `Email`, `Relationship` FROM `parents`"
            command.CommandText = querystr
            command.Connection = conn

            datareader = command.ExecuteReader

            table.Load(datareader)

            grid_parents.DataSource = table
            With grid_parents
                .Columns(0).HeaderText = "Parent ID"
                .Columns(1).HeaderText = "NIC Number"
                .Columns(2).HeaderText = "Occupation"
                .Columns(3).HeaderText = "Phone Number"
                .Columns(4).HeaderText = "Email"
                .Columns(5).HeaderText = "Relationship"




            End With




        End If


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles bntpdreports.Click
        Manager_Reports.Show()
        Me.Hide()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class