﻿Public Class Manager_Reports
    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles bntback.Click
        manager_dashbord.Show()
        Me.Hide()

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles bntsd.Click
        Report_Student_Details.Show()
        Me.Hide()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles bntsa.Click
        Report_Student_Attendancevb.Show()
        Me.Hide()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        teacher_Reports.Show()
        Me.Hide()


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Teacher_Attendance_Report.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles bntpd.Click
        Report_parents_details.Show()
        Me.Hide()

    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles bnttpa.Click
        Teacher_payments_report.Show()
        Me.Hide()


    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles bntcr.Click
        Class_Result_Report.Show()
        Me.Hide()


    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles bntcd.Click
        Class_details.Show()
        Me.Hide()
    End Sub

    Private Sub Manager_Reports_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class