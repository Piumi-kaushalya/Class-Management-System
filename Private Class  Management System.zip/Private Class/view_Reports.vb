﻿Public Class view_Reports
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Class_Result_Report.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Report_Student_Attendancevb.Show()
        Me.Hide()
    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        teacher_dashbord.Show()
        Me.Hide()
    End Sub
End Class