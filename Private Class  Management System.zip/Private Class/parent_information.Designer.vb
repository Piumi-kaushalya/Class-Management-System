﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class parent_information
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.bntback = New System.Windows.Forms.Button()
        Me.Bntreset = New System.Windows.Forms.Button()
        Me.Bntsave = New System.Windows.Forms.Button()
        Me.Cmbrelationship = New System.Windows.Forms.ComboBox()
        Me.Txtoccupation = New System.Windows.Forms.TextBox()
        Me.Txtphone = New System.Windows.Forms.TextBox()
        Me.Txtemail = New System.Windows.Forms.TextBox()
        Me.txtnic = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.bntback)
        Me.Panel2.Controls.Add(Me.Bntreset)
        Me.Panel2.Controls.Add(Me.Bntsave)
        Me.Panel2.Controls.Add(Me.Cmbrelationship)
        Me.Panel2.Controls.Add(Me.Txtoccupation)
        Me.Panel2.Controls.Add(Me.Txtphone)
        Me.Panel2.Controls.Add(Me.Txtemail)
        Me.Panel2.Controls.Add(Me.txtnic)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Location = New System.Drawing.Point(32, 86)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(776, 474)
        Me.Panel2.TabIndex = 3
        '
        'bntback
        '
        Me.bntback.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.bntback.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntback.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.bntback.Location = New System.Drawing.Point(600, 368)
        Me.bntback.Margin = New System.Windows.Forms.Padding(4)
        Me.bntback.Name = "bntback"
        Me.bntback.Size = New System.Drawing.Size(144, 56)
        Me.bntback.TabIndex = 70
        Me.bntback.Text = "Back"
        Me.bntback.UseVisualStyleBackColor = False
        '
        'Bntreset
        '
        Me.Bntreset.BackColor = System.Drawing.Color.Silver
        Me.Bntreset.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bntreset.ForeColor = System.Drawing.Color.White
        Me.Bntreset.Location = New System.Drawing.Point(408, 368)
        Me.Bntreset.Name = "Bntreset"
        Me.Bntreset.Size = New System.Drawing.Size(144, 56)
        Me.Bntreset.TabIndex = 9
        Me.Bntreset.Text = "Reset"
        Me.Bntreset.UseVisualStyleBackColor = False
        '
        'Bntsave
        '
        Me.Bntsave.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Bntsave.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bntsave.ForeColor = System.Drawing.Color.White
        Me.Bntsave.Location = New System.Drawing.Point(224, 368)
        Me.Bntsave.Name = "Bntsave"
        Me.Bntsave.Size = New System.Drawing.Size(144, 56)
        Me.Bntsave.TabIndex = 8
        Me.Bntsave.Text = "Save"
        Me.Bntsave.UseVisualStyleBackColor = False
        '
        'Cmbrelationship
        '
        Me.Cmbrelationship.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmbrelationship.FormattingEnabled = True
        Me.Cmbrelationship.Items.AddRange(New Object() {"Father", "Mother", "Others"})
        Me.Cmbrelationship.Location = New System.Drawing.Point(296, 285)
        Me.Cmbrelationship.Name = "Cmbrelationship"
        Me.Cmbrelationship.Size = New System.Drawing.Size(341, 33)
        Me.Cmbrelationship.TabIndex = 7
        '
        'Txtoccupation
        '
        Me.Txtoccupation.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtoccupation.Location = New System.Drawing.Point(296, 117)
        Me.Txtoccupation.Name = "Txtoccupation"
        Me.Txtoccupation.Size = New System.Drawing.Size(341, 30)
        Me.Txtoccupation.TabIndex = 4
        '
        'Txtphone
        '
        Me.Txtphone.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtphone.Location = New System.Drawing.Point(296, 173)
        Me.Txtphone.Name = "Txtphone"
        Me.Txtphone.Size = New System.Drawing.Size(341, 30)
        Me.Txtphone.TabIndex = 5
        '
        'Txtemail
        '
        Me.Txtemail.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtemail.Location = New System.Drawing.Point(296, 229)
        Me.Txtemail.Name = "Txtemail"
        Me.Txtemail.Size = New System.Drawing.Size(341, 30)
        Me.Txtemail.TabIndex = 6
        '
        'txtnic
        '
        Me.txtnic.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnic.Location = New System.Drawing.Point(296, 61)
        Me.txtnic.Name = "txtnic"
        Me.txtnic.Size = New System.Drawing.Size(341, 30)
        Me.txtnic.TabIndex = 3
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(128, 184)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(129, 29)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "Phone No"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(128, 240)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(79, 29)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Email"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(128, 62)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 29)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "NIC No"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(128, 288)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(159, 29)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Relationship" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(128, 128)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(122, 25)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Occupation"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(32, 24)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(776, 65)
        Me.Panel1.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(200, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(372, 44)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Parents Information" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'parent_information
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumAquamarine
        Me.ClientSize = New System.Drawing.Size(838, 596)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "parent_information"
        Me.Text = "Form1"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel2 As Panel
    Friend WithEvents Bntreset As Button
    Friend WithEvents Bntsave As Button
    Friend WithEvents Cmbrelationship As ComboBox
    Friend WithEvents Txtoccupation As TextBox
    Friend WithEvents Txtphone As TextBox
    Friend WithEvents Txtemail As TextBox
    Friend WithEvents txtnic As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents bntback As Button
End Class
