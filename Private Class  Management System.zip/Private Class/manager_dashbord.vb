﻿Public Class manager_dashbord
    Private Sub bntreg_Click(sender As Object, e As EventArgs)
        Registration_select.Show()
        Me.Hide()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)
        Registration_select.Show()
        Me.Hide()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        login.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Add_Registration.Show()
        Me.Hide()

    End Sub

    Private Sub bntst_attendence_Click(sender As Object, e As EventArgs)
        Finance.Show()
        Me.Hide()

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)
        Manager_Reports.Show()
        Me.Hide()

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click


    End Sub
End Class