﻿Imports MySql.Data.MySqlClient
Public Class teacher_Reports
    Dim command As New MySqlCommand
    Dim datareader As MySqlDataReader
    Dim querystr As String
    Dim table As New DataTable

    Private Sub Teacher_Details_List_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Open_db()

        querystr = "SELECT Teacher_Id, First_Name, Last_Name, NIC_No, Phone_No, Email, Subject FROM teacher"
        command.CommandText = querystr
        command.Connection = conn

        datareader = command.ExecuteReader

        table.Load(datareader)

        grid_teacher.DataSource = table
        With grid_teacher


            .Columns(1).HeaderText = "Teacher_Id"
            .Columns(2).HeaderText = "First_Name"
            .Columns(3).HeaderText = " Last_Name"
            .Columns(4).HeaderText = " NIC_No"
            .Columns(5).HeaderText = "Phone_No"
            .Columns(6).HeaderText = "Email"
            ' .Columns(7).HeaderText = "Subject"



        End With

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Manager_Reports.Show()
        Me.Hide()

    End Sub
End Class