﻿Public Class Profit
    Private Sub View_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Finance.Show()
        Me.Hide()

    End Sub

    Private Sub Profit_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim st_amount, the_amount, wbill_amount, e_amount, rent_amount, phone_amount, Advertising_amount As Integer
        Dim income, expn, profit As Integer
        If Open_db() Then
            st_amount = student_amount()
            income = st_amount
            lblincome.Text = "Rs. " & income

            the_amount = teacher_amount()
            wbill_amount = waterbill_amount()
            e_amount = ebill_amount()
            rent_amount = ren_amount()
            phone_amount = pbill_amount()
            Advertising_amount = add_amount()

            expn = (the_amount + wbill_amount + ebill_amount() + ren_amount() + phone_amount + Advertising_amount)

            lblexpences.Text = "Rs. " & expn

            profit = income - expn
            lblprofit.Text = "Rs. " & profit
        End If

    End Sub

End Class
