﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class parent_information

    Dim command As New MySqlCommand
    Dim querystr As String

    Private Sub Bntsave_Click(sender As Object, e As EventArgs) Handles Bntsave.Click
        'Dim parent_id As Integer
        Dim nic_no, occupation, phone_no, email, relationship, querystr As String
        Dim result As Boolean

        'parent_id = cmb
        nic_no = txtnic.Text
        occupation = Txtoccupation.Text
        phone_no = Txtphone.Text
        email = Txtemail.Text
        relationship = Cmbrelationship.Text
        If empty(nic_no) Or empty(occupation) Or empty(phone_no) Or empty(email) Or empty(relationship) Then
            MsgBox("All Filds are Required")

        Else


            If Open_db() Then


                querystr = "INSERT INTO `parents`(`NIC_No`, `Occupation`, `Phone_No`, `Email`, `Relationship`) VALUES (@NIC, @OCC, @PH, @EMAIL, @RELATIONSHIP)"
                Dim command As New MySqlCommand(querystr, conn)

                'command.Parameters.Add("@ST", MySqlDbType.Int16).Value = c
                command.Parameters.Add("@NIC", MySqlDbType.VarChar).Value = nic_no
                command.Parameters.Add("@OCC", MySqlDbType.VarChar).Value = occupation
                command.Parameters.Add("@PH", MySqlDbType.Int16).Value = phone_no
                command.Parameters.Add("@EMAIL", MySqlDbType.VarChar).Value = email
                command.Parameters.Add("@RELATIONSHIP", MySqlDbType.VarChar).Value = relationship


                Try
                    result = command.ExecuteNonQuery()

                    If result = True Then


                        MsgBox("Add parent infomation")
                    Else
                        MsgBox("Not Add parent infomationt")
                    End If

                Catch ex As Exception
                    MsgBox(ex.Message)



                End Try
            Else
                MsgBox("Connection error")

            End If
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles bntback.Click
        Registration_select.Show()
        Me.Hide()

    End Sub

    Private Sub Bntreset_Click(sender As Object, e As EventArgs) Handles Bntreset.Click
        txtnic.Text = ""
        Txtemail.Text = ""
        Txtoccupation.Text = ""
        Txtphone.Text = ""
    End Sub

    Private Sub Txtoccupation_TextChanged(sender As Object, e As EventArgs) Handles Txtoccupation.TextChanged

    End Sub

    Private Sub Txtoccupation_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txtoccupation.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If

    End Sub

    Private Sub Txtphone_TextChanged(sender As Object, e As EventArgs) Handles Txtphone.TextChanged

    End Sub

    Private Sub Txtphone_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txtphone.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Txtemail_Leave(sender As Object, e As EventArgs) Handles Txtemail.Leave
        Dim pattern As String
        pattern = "^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"
        If Not Regex.IsMatch(Txtemail.Text, pattern) Then
            Txtemail.Focus()
            MsgBox("Not a valid Email address ")
            Return
        End If
    End Sub

    Private Sub Txtemail_TextChanged(sender As Object, e As EventArgs) Handles Txtemail.TextChanged

    End Sub
End Class
