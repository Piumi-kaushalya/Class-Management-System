﻿Imports MySql.Data.MySqlClient

Public Class login
    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        Dim user_name As String
        Dim password As String
        '  Dim DBconect As String
        Dim querystr As String
        Dim count As Integer

        'Dim command1 As MySqlCommand


        user_name = Textusername.Text
        password = Textpassword.Text


        If Open_db() Then
            querystr = "SELECT User_Role FROM `users` WHERE NIC_No = '" & Textusername.Text & "' AND Password = '" & Textpassword.Text & "' "
            Dim command1 As New MySqlCommand(querystr, conn)
            Dim reader As MySqlDataReader
            Dim userRole As String
            reader = command1.ExecuteReader
            count = 0
            While reader.Read
                count = count + 1
            End While

            'userRole = reader()


            If count > 0 Then
                userRole = reader.GetString(0)
                If userRole = "Teacher" Then
                    teacher_dashbord.Show()
                ElseIf userRole = "Manager" Then
                    manager_dashbord.Show()
                ElseIf userRole = "Admin" Then
                    admin.Show()
                End If
                'MessageBox.Show(userRole)
            Else
                MessageBox.Show("INVALID Username or Password")
            End If
        Else
            MsgBox("Connection Fails")
        End If




    End Sub

    Private Sub Textpassword_TextChanged(sender As Object, e As EventArgs) Handles Textpassword.TextChanged

    End Sub
End Class