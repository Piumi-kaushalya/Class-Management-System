﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class Add_Ol_result
    Private Sub bntsave_Click(sender As Object, e As EventArgs) Handles bntsave.Click
        Dim student_id As Integer
        Dim year As Integer
        Dim attempt As String
        Dim sub1, sub2, sub3, sub4, sub5, sub6, result1, result2, result3, result4, result5, result6 As String
        Dim str As String
        Dim result As Boolean

        student_id = txtstuid.Text
        year = txtyear.Text
        attempt = cmbattemt.SelectedItem
        sub1 = txtsub1.Text
        sub2 = txtsub2.Text
        sub3 = txtsub3.Text
        sub4 = txtsub4.Text
        sub5 = txtsub5.Text
        sub6 = txtsub6.Text
        result1 = txtresult1.Text
        result2 = txtresult2.Text
        result3 = txtresult3.Text
        result4 = txtresult4.Text
        result5 = txtresult5.Text
        result6 = txtresult6.Text

        If empty(student_id) Or empty(year) Or empty(attempt) Or empty(sub1) Or empty(sub2) Or empty(sub3) Or empty(sub4) Or empty(sub5) Or empty(sub6) Or empty(result1) Or empty(result2) Or empty(result3) Or empty(result4) Or empty(result5) Or empty(result6) Then
            MsgBox("All Filds are Required")

        Else


            If Open_db() Then


                str = "INSERT INTO `odinary_level_results`(`Student_Id`, `Year`, `Attempt`, `Subject1`, `Result1`, `Subject2`, `Result2`, `Subject3`, `Result3`, `Subject4`, `Result4`, `Subject5`, `Result5`, `subject6`, `Result6`) VALUES(@STID,@Y,@ATT,@SUB1,@RES1,@SUB2,@RES2,@SUB3,@RES3,@SUB4,@RES4,@SUB5,@RES5,@SUB6,@RES6)"
                Dim command As New MySqlCommand(str, conn)



                command.Parameters.Add("@STID", MySqlDbType.Int32).Value = student_id

                command.Parameters.Add("@Y", MySqlDbType.VarChar).Value = year
                command.Parameters.Add("@ATT", MySqlDbType.VarChar).Value = attempt

                command.Parameters.Add("@SUB1", MySqlDbType.VarChar).Value = sub1
                command.Parameters.Add("@RES1", MySqlDbType.VarChar).Value = result1
                command.Parameters.Add("@SUB2", MySqlDbType.VarChar).Value = sub2
                command.Parameters.Add("@RES2", MySqlDbType.VarChar).Value = result2
                command.Parameters.Add("@SUB3", MySqlDbType.VarChar).Value = sub3
                command.Parameters.Add("@RES3", MySqlDbType.VarChar).Value = result3
                command.Parameters.Add("@SUB4", MySqlDbType.VarChar).Value = sub4
                command.Parameters.Add("@RES4", MySqlDbType.VarChar).Value = result4
                command.Parameters.Add("@SUB5", MySqlDbType.VarChar).Value = sub5
                command.Parameters.Add("@RES5", MySqlDbType.VarChar).Value = result5
                command.Parameters.Add("@SUB6", MySqlDbType.VarChar).Value = sub6
                command.Parameters.Add("@RES6", MySqlDbType.VarChar).Value = result6




                Try
                    result = command.ExecuteNonQuery()

                    If result = True Then


                        MsgBox("Added Result")
                    Else
                        MsgBox("Not Add Result")
                    End If

                Catch ex As Exception
                    MsgBox(ex.Message)



                End Try
            Else
                MsgBox("Connection error")

            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles bntback.Click
        Select_Result.Show()
        Me.Hide()

    End Sub

    Private Sub bntreset_Click(sender As Object, e As EventArgs) Handles bntreset.Click
        txtresult1.Text = ""
        txtsub1.Text = ""
        txtsub2.Text = ""
        txtsub3.Text = ""
        txtsub5.Text = ""
        txtsub6.Text = ""
        txtyear.Text = ""
        txtresult3.Text = ""
        txtresult4.Text = ""
        txtresult5.Text = ""
        txtresult6.Text = ""
        txtstuid.Text = ""


    End Sub

    Private Sub txtsub1_TextChanged(sender As Object, e As EventArgs) Handles txtsub1.TextChanged

    End Sub

    Private Sub txtsub1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsub1.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtsub2_TextChanged(sender As Object, e As EventArgs) Handles txtsub2.TextChanged

    End Sub

    Private Sub txtsub2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsub2.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtsub3_TextChanged(sender As Object, e As EventArgs) Handles txtsub3.TextChanged

    End Sub

    Private Sub txtsub3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsub3.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtsub4_TextChanged(sender As Object, e As EventArgs) Handles txtsub4.TextChanged

    End Sub

    Private Sub txtsub4_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsub4.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtsub5_TextChanged(sender As Object, e As EventArgs) Handles txtsub5.TextChanged

    End Sub

    Private Sub txtsub5_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsub5.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtsub6_TextChanged(sender As Object, e As EventArgs) Handles txtsub6.TextChanged

    End Sub

    Private Sub txtsub6_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsub6.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtresult1_TextChanged(sender As Object, e As EventArgs) Handles txtresult1.TextChanged

    End Sub

    Private Sub txtresult1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtresult1.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtresult2_TextChanged(sender As Object, e As EventArgs) Handles txtresult2.TextChanged

    End Sub

    Private Sub txtresult2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtresult2.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtresult3_TextChanged(sender As Object, e As EventArgs) Handles txtresult3.TextChanged

    End Sub

    Private Sub txtresult3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtresult3.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtresult4_TextChanged(sender As Object, e As EventArgs) Handles txtresult4.TextChanged

    End Sub

    Private Sub txtresult4_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtresult4.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtresult5_TextChanged(sender As Object, e As EventArgs) Handles txtresult5.TextChanged

    End Sub

    Private Sub txtresult5_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtresult5.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtresult6_TextChanged(sender As Object, e As EventArgs) Handles txtresult6.TextChanged

    End Sub

    Private Sub txtresult6_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtresult6.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtstuid_TextChanged(sender As Object, e As EventArgs) Handles txtstuid.TextChanged

    End Sub

    Private Sub txtstuid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtstuid.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtyear_TextChanged(sender As Object, e As EventArgs) Handles txtyear.TextChanged

    End Sub

    Private Sub txtyear_KeyUp(sender As Object, e As KeyEventArgs) Handles txtyear.KeyUp

    End Sub

    Private Sub txtyear_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtyear.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub
End Class