﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class teacher_dashbord
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(teacher_dashbord))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.bntrepots = New System.Windows.Forms.Button()
        Me.bntresult = New System.Windows.Forms.Button()
        Me.bntst_attendence = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1008, 552)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Black
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.Yellow
        Me.Button2.Location = New System.Drawing.Point(32, 480)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(140, 60)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "Logout"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'bntrepots
        '
        Me.bntrepots.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntrepots.FlatAppearance.BorderSize = 5
        Me.bntrepots.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntrepots.ForeColor = System.Drawing.Color.White
        Me.bntrepots.Location = New System.Drawing.Point(600, 352)
        Me.bntrepots.Name = "bntrepots"
        Me.bntrepots.Size = New System.Drawing.Size(184, 48)
        Me.bntrepots.TabIndex = 8
        Me.bntrepots.Text = "Reports"
        Me.bntrepots.UseVisualStyleBackColor = False
        '
        'bntresult
        '
        Me.bntresult.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntresult.FlatAppearance.BorderSize = 5
        Me.bntresult.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntresult.ForeColor = System.Drawing.Color.White
        Me.bntresult.Location = New System.Drawing.Point(600, 272)
        Me.bntresult.Name = "bntresult"
        Me.bntresult.Size = New System.Drawing.Size(184, 48)
        Me.bntresult.TabIndex = 7
        Me.bntresult.Text = "Add Result"
        Me.bntresult.UseVisualStyleBackColor = False
        '
        'bntst_attendence
        '
        Me.bntst_attendence.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntst_attendence.FlatAppearance.BorderSize = 5
        Me.bntst_attendence.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntst_attendence.ForeColor = System.Drawing.Color.White
        Me.bntst_attendence.Location = New System.Drawing.Point(600, 192)
        Me.bntst_attendence.Name = "bntst_attendence"
        Me.bntst_attendence.Size = New System.Drawing.Size(184, 48)
        Me.bntst_attendence.TabIndex = 4
        Me.bntst_attendence.Text = "Attendence"
        Me.bntst_attendence.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 30.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(40, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(905, 58)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Sigma Insutituute Managment System"
        '
        'teacher_dashbord
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1007, 552)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.bntrepots)
        Me.Controls.Add(Me.bntresult)
        Me.Controls.Add(Me.bntst_attendence)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "teacher_dashbord"
        Me.Text = "teacher_dashbord"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button2 As Button
    Friend WithEvents bntrepots As Button
    Friend WithEvents bntresult As Button
    Friend WithEvents bntst_attendence As Button
    Friend WithEvents Label1 As Label
End Class
