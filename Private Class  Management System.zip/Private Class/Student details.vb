﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class Student_details


    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If Open_db() Then
            Dim querystr As String

            'querystr = "SELECT * FROM (`students`, `parents`) WHERE Student_Id = '" & txtsid.Text & "'"
            querystr = "SELECT * FROM `students` WHERE Student_Id = '" & txtsid.Text & "'"
            Dim command1 As New MySqlCommand(querystr, conn)
            Dim reader As MySqlDataReader
            Dim parentID As Integer
            Dim firstName As String
            Dim lastName As String
            Dim street As String
            Dim city As String
            Dim school As String
            Dim birh_of_date As Date
            Dim gender As String


            reader = command1.ExecuteReader
            reader.Read()
            parentID = reader.GetString(1)
            firstName = reader.GetString(2)
            lastName = reader.GetString(3)
            street = reader.GetString(4)
            city = reader.GetString(5)
            school = reader.GetString(6)
            birh_of_date = reader.GetString(7)
            gender = reader.GetString(8)
            reader.Close()

            txtParentID.Text = parentID
            txtFirstName.Text = firstName
            txtlastname.Text = lastName
            txtstreet.Text = street
            txtcity.Text = city
            txtschool.Text = school
            txtbirth.Text = birh_of_date
            txtgender.Text = gender


        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles bntupdate.Click
        Dim queryupdate, firstName, lastName, street, city, school, gender As String
        Dim birh_of_date As Date
        Dim student_id, parentID As Integer
        Dim result As Boolean
        student_id = txtsid.Text
        parentID = txtParentID.Text
        firstName = txtFirstName.Text
        lastName = txtlastname.Text
        street = txtstreet.Text
        city = txtcity.Text
        school = txtschool.Text
        birh_of_date = txtbirth.Text
        gender = txtgender.Text

        If Open_db() Then
            queryupdate = "UPDATE `students` SET `Parent_Id`=@parent,`First_Name`=@fn,`Last_Name`=@ln,`Street`=@s,`City`=@c,`School`=@school,`Date_Of_Birth`=@dob,`Gender`=@g WHERE Student_Id=@sid"
            Dim command As New MySqlCommand(queryupdate, conn)

            command.Parameters.Add("@sid", MySqlDbType.Int32).Value = student_id
            command.Parameters.Add("@parent", MySqlDbType.Int32).Value = parentID
            command.Parameters.Add("@fn", MySqlDbType.VarChar).Value = firstName
            command.Parameters.Add("@ln", MySqlDbType.VarChar).Value = lastName
            command.Parameters.Add("@s", MySqlDbType.VarChar).Value = street
            command.Parameters.Add("@c", MySqlDbType.VarChar).Value = city
            command.Parameters.Add("@school", MySqlDbType.VarChar).Value = school
            command.Parameters.Add("@dob", MySqlDbType.Date).Value = birh_of_date
            command.Parameters.Add("@g", MySqlDbType.VarChar).Value = gender

            Try
                result = command.ExecuteNonQuery()
                If result Then
                    MsgBox("successfully updated")
                    txtParentID.Text = ""
                    txtFirstName.Text = ""
                    txtlastname.Text = ""
                    txtstreet.Text = ""
                    txtcity.Text = ""
                    txtschool.Text = ""
                    txtbirth.Text = ""
                    txtgender.Text = ""
                Else
                    MsgBox("Not Added")


                End If
            Catch ex As Exception

                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub bntdelete_Click(sender As Object, e As EventArgs) Handles bntdelete.Click
        Dim query As String
        Dim result As Boolean

        If Open_db() Then
            query = "DELETE FROM `students` WHERE Student_Id='" & txtsid.Text & "'"
            Dim command As New MySqlCommand(query, conn)
            Try
                result = command.ExecuteNonQuery()
                If result Then
                    MsgBox("successfully deleted")
                Else
                    MsgBox("Failed")
                End If
            Catch ex As Exception

            End Try
        End If
    End Sub

    Private Sub Student_details_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Add_Registration.Show()
        Me.Hide()

    End Sub

    Private Sub txtsid_TextChanged(sender As Object, e As EventArgs) Handles txtsid.TextChanged

    End Sub

    Private Sub txtsid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsid.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtParentID_TextChanged(sender As Object, e As EventArgs) Handles txtParentID.TextChanged

    End Sub

    Private Sub txtParentID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtParentID.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtFirstName_TextChanged(sender As Object, e As EventArgs) Handles txtFirstName.TextChanged

    End Sub

    Private Sub txtFirstName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtFirstName.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtlastname_TextChanged(sender As Object, e As EventArgs) Handles txtlastname.TextChanged

    End Sub

    Private Sub txtlastname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtlastname.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtstreet_TextChanged(sender As Object, e As EventArgs) Handles txtstreet.TextChanged

    End Sub

    Private Sub txtstreet_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtstreet.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtcity_TextChanged(sender As Object, e As EventArgs) Handles txtcity.TextChanged

    End Sub

    Private Sub txtcity_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtcity.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtschool_TextChanged(sender As Object, e As EventArgs) Handles txtschool.TextChanged

    End Sub

    Private Sub txtschool_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtschool.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub
End Class