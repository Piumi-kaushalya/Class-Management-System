﻿Imports MySql.Data.MySqlClient
Public Class Class_Result_Report

    Dim command As New MySqlCommand
    Dim datareader As MySqlDataReader
    Dim querystr As String
    Dim table As New DataTable
    Dim result As Boolean


    Private Sub bntok_Click(sender As Object, e As EventArgs) Handles bntok.Click
        Dim class_result As String
        class_result = cmbexam_name.Text

        If Open_db() Then
            querystr = " SELECT `Class_Result_Id`, `Class_Id`, `Student_Id`, `Marks`, `Class_Exam_Name` FROM `class_results`"
            command.CommandText = querystr
            command.Connection = conn
            command.Parameters.Add("@result", MySqlDbType.VarChar).Value = "Class_Exam_Name"

            datareader = command.ExecuteReader
            table.Load(datareader)

            gridclas_result.DataSource = table

        End If


    End Sub

    Private Sub Class_Result_Report_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If Open_db() Then


            querystr = "SELECT * FROM class_results"

            command.CommandText = querystr
            command.Connection = conn




            datareader = command.ExecuteReader
            table.Load(datareader)

            cmbexam_name.DataSource = table
            cmbexam_name.DisplayMember = "Student_Id"
            cmbexam_name.ValueMember = "Class_Result_Id"

            gridclas_result.DataSource = table

            With gridclas_result
                .Columns(0).HeaderText = "Class_Result_Id"
                .Columns(1).HeaderText = "Class_Id"
                .Columns(2).HeaderText = "Student_Id"
                .Columns(3).HeaderText = "Marks"
                .Columns(4).HeaderText = "Class_Exam_Name"


                '.Columns(1).Width = 150

                .Columns(0).Visible = False
                '.Columns(2).Visible = True
            End With
        Else
            MsgBox("connection error")


        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        view_Reports.Show()
        Me.Hide()

    End Sub
End Class