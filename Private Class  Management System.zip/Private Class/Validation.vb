﻿Imports MySql.Data.MySqlClient
Module Validation
    Dim result As Boolean
    Public Function mobile_validation(ByVal inputvalue1 As String) As Boolean
        If inputvalue1.Length < 11 And inputvalue1.Length >= 10 Then

            result = True

        Else
            MsgBox("Phone Number have 10 Digits!")
                result = False
                Return result
            End If

        Return result
    End Function

    Public Function empty(ByVal inputvalue As String) As Boolean

        inputvalue = Trim(inputvalue)
        If String.IsNullOrEmpty(inputvalue) Then
            result = True
        Else
            result = False
        End If
        Return result

    End Function

    Public Function marks_validation(ByVal inputvalue1 As String) As Boolean
        If inputvalue1.Length <= 100 Then

            result = True

        Else
            MsgBox("Recheck Marks", vbExclamation)
            result = False
            Return result
        End If

        Return result
    End Function

    Public Function student_amount()
        Dim qsr5 As String
        Dim amount As Integer
        qsr5 = "SELECT SUM(`Amount`) FROM `student_fees`"
        Dim command As New MySqlCommand(qsr5, conn)
        amount = command.ExecuteScalar
        Return amount
    End Function

    Public Function teacher_amount()
        Dim qsr5 As String
        Dim amount As Integer
        qsr5 = "SELECT SUM(`Amount`) FROM `teacher_payments`"
        Dim command As New MySqlCommand(qsr5, conn)
        amount = command.ExecuteScalar
        Return amount
    End Function

    Public Function waterbill_amount()
        Dim qsr5 As String
        Dim amount As Integer
        qsr5 = "SELECT SUM(`Water_bill`) FROM `expensess`"
        Dim command As New MySqlCommand(qsr5, conn)
        amount = command.ExecuteScalar
        Return amount

    End Function

    Public Function ebill_amount()
        Dim qsr5 As String
        Dim amount As Integer
        qsr5 = "SELECT SUM(`Eleyicity_bill`) FROM `expensess`"
        Dim command As New MySqlCommand(qsr5, conn)
        amount = command.ExecuteScalar
        Return amount
    End Function

    Public Function ren_amount()
        Dim qsr5 As String
        Dim amount As Integer
        qsr5 = "SELECT SUM(`Rent`) FROM `expensess`"
        Dim command As New MySqlCommand(qsr5, conn)
        amount = command.ExecuteScalar
        Return amount

    End Function

    Public Function pbill_amount()
        Dim qsr5 As String
        Dim amount As Integer
        qsr5 = "SELECT sum(`Phone_bill`) FROM `expensess`"
        Dim command As New MySqlCommand(qsr5, conn)
        amount = command.ExecuteScalar
        Return amount

    End Function

    Public Function add_amount()
        Dim qsr5 As String
        Dim amount As Integer
        qsr5 = "SELECT sum(`Advertising`) FROM `expensess`"
        Dim command As New MySqlCommand(qsr5, conn)
        amount = command.ExecuteScalar
        Return amount

    End Function
End Module
