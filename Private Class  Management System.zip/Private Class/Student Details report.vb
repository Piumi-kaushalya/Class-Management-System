﻿Imports MySql.Data.MySqlClient
Public Class Report_Student_Details
    Dim command As New MySqlCommand
    Dim datareader As MySqlDataReader
    Dim table As New DataTable
    Dim str As String
    Dim result As Boolean

    Private Sub Student_Details_List_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Open_db() Then


            str = "SELECT `Student_Id`, `Parent_Id`, `First_Name`, `Last_Name`, `Street`, `City`, `School`, `Date_Of_Birth`, `Gender` FROM `students`"
            command.CommandText = str
            command.Connection = conn

            datareader = command.ExecuteReader
            table.Load(datareader)

            grid_student.DataSource = table

            With grid_student
                .Columns(0).HeaderText = "Student Id"
                .Columns(1).HeaderText = "Parent Id"
                .Columns(2).HeaderText = "First Name"
                .Columns(3).HeaderText = "Last Name"
                .Columns(4).HeaderText = "Street"
                .Columns(5).HeaderText = "city"
                .Columns(6).HeaderText = "School"
                .Columns(7).HeaderText = "Date of birth"
                .Columns(7).HeaderText = "Gender"
                '.Columns(1).Width = 150

                .Columns(0).Visible = False
                '.Columns(2).Visible = True
            End With
        Else
            MsgBox("connection error")

        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Manager_Reports.Show()
        Me.Hide()

    End Sub
End Class