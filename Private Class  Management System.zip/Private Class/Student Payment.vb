﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class Student_Payment
    Dim querystr As String
    Dim datareader As MySqlDataReader

    Private Sub Student_Payment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim table As New DataTable
        Dim command2 As New MySqlCommand

        Dim class_Id As String
        class_Id = cmbcname.Text
        Open_db()


        querystr = "SELECT * FROM `class`"
        command2.CommandText = querystr
        command2.Connection = conn

        datareader = command2.ExecuteReader
        table.Load(datareader)


        cmbcname.DataSource = table
        cmbcname.DisplayMember = "Class_Name"
        cmbcname.ValueMember = "Class_Id"
    End Sub

    Private Sub bntpayment_Click(sender As Object, e As EventArgs) Handles bntpayment.Click
        Dim class_name, description, querystr As String
        Dim date_of_class As Date
        Dim student_id As Integer
        Dim amount As Integer
        Dim result As Boolean


        class_name = cmbcname.SelectedValue
        description = txtdescription.Text
        date_of_class = pdate.Value
        student_id = txtsid.Text
        amount = txtamount.Text
        If Open_db() Then


            querystr = "INSERT INTO `student_fees`(`Student_Id`, `Class_Name`, `Amount`, `Payment_Date`, `Description`) VALUES (@sid, @cname, @amount, @pday, @description)"
            Dim command As New MySqlCommand(querystr, conn)

            command.Parameters.Add("@sid", MySqlDbType.Int32).Value = student_id
            command.Parameters.Add("@cname", MySqlDbType.VarChar).Value = class_name
            command.Parameters.Add("@amount", MySqlDbType.Int32).Value = amount
            command.Parameters.Add("@pday", MySqlDbType.Date).Value = date_of_class
            command.Parameters.Add("@description", MySqlDbType.VarChar).Value = description



            Try
                result = command.ExecuteNonQuery()

                If result = True Then


                    MsgBox("Add class Fees")
                Else
                    MsgBox("Not Add class Fees")
                End If

            Catch ex As Exception
                MsgBox(ex.Message)



            End Try
        Else
            MsgBox("Connection error")

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        txtamount.Text = ""
        txtdescription.Text = ""
        txtsid.Text = ""
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Finance.Show()
        Me.Hide()
    End Sub

    Private Sub txtsid_TextChanged(sender As Object, e As EventArgs) Handles txtsid.TextChanged

    End Sub

    Private Sub txtsid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsid.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtamount_TextChanged(sender As Object, e As EventArgs) Handles txtamount.TextChanged

    End Sub

    Private Sub txtamount_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtamount.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub
End Class