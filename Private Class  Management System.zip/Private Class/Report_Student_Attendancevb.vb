﻿Imports MySql.Data.MySqlClient
Public Class Report_Student_Attendancevb
    Dim command As New MySqlCommand
    Dim datareader As MySqlDataReader
    Dim querystr As String
    Dim table As New DataTable
    Private Sub Report_Student_Attendancevb_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If Open_db() Then

            Dim qury1 As String
            Dim da1 As New MySqlDataAdapter
            Dim dt1 As New DataTable


            qury1 = "SELECT * FROM class"
            da1.SelectCommand = New MySqlCommand(qury1, conn)
            da1.Fill(dt1)
            cmbclass.DataSource = dt1
            cmbclass.DisplayMember = "Class_Name"
            cmbclass.ValueMember = "Class_Id"


        Else
            MsgBox("Connection Fails")

        End If


    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbclass.SelectedIndexChanged

    End Sub

    Private Sub bntok_Click(sender As Object, e As EventArgs) Handles bntok.Click
        If Open_db() Then


            querystr = "SELECT * FROM (student_attendence, class) WHERE (class.Class_Id=student_attendence.Class_Id AND student_attendence.Class_Id='" & cmbclass.SelectedValue & "')"
            command.CommandText = querystr
            command.Connection = conn

            datareader = command.ExecuteReader

            table.Load(datareader)

            grid_student.DataSource = table
            With grid_student
                .Columns(0).HeaderText = "Attendence ID"
                .Columns(1).HeaderText = "Student ID"
                .Columns(2).HeaderText = "Class ID"
                .Columns(3).HeaderText = "Date"

                '.Columns(0).ReadOnly = True
                ' .Columns(1).ReadOnly = True
                '.Columns(2).ReadOnly = True
                ' .Columns(3).ReadOnly = True


                .Columns(0).Visible = False
                .Columns(2).Visible = False

            End With

            'cmbclass.ValueMember = "ClassId"




            '
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        view_Reports.Show()
        Me.Hide()

    End Sub
End Class