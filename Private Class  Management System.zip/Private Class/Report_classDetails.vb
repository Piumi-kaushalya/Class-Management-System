﻿Imports MySql.Data.MySqlClient
Public Class Class_details
    Dim command As New MySqlCommand
    Dim datareader As MySqlDataReader
    Dim querystr As String
    Dim table As New DataTable

    Private Sub Class_details_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Open_db() Then


            querystr = "SELECT `Class_Id`, `Class_Date`, `Class_Time`, `Teacher_Id`, `Class_Name` FROM `class`"
            command.CommandText = querystr
            command.Connection = conn

            datareader = command.ExecuteReader

            table.Load(datareader)

            grid_class.DataSource = table
            With grid_class
                .Columns(0).HeaderText = "Class ID"
                .Columns(1).HeaderText = "Class Date"
                .Columns(2).HeaderText = "Class Time"
                .Columns(3).HeaderText = "Teacher Id"
                .Columns(4).HeaderText = "Class Name"


                .Columns(1).ReadOnly = True
                .Columns(2).ReadOnly = True
                .Columns(3).ReadOnly = True
                .Columns(4).ReadOnly = True

                .Columns(1).Visible = False
                '.Columns(3).Visible = False



            End With




        End If


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles bntback.Click
        Manager_Reports.Show()
        Me.Hide()

    End Sub
End Class