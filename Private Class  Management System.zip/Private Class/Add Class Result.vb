﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions

Public Class Add_class_result


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles bntsave.Click
        Dim class_id As Integer
        Dim student_id As Integer
        Dim querystr As String
        Dim marks As Integer
        Dim class_exam_name As String
        Dim result As Boolean

        class_id = txtcid.Text
        student_id = txtsid.Text
        marks = txtmark.Text
        class_exam_name = txtclassexamname.Text

        If empty(class_id) Or empty(student_id) Or empty(marks) Or empty(class_exam_name) Then
            MsgBox("All Filds are Required")
            Return
        Else
            If marks_validation(txtmark.Text) Then
                MsgBox("Recheck Marks")
            Else

                If Open_db() Then
                    querystr = "INSERT INTO `class_results`(`Class_Id`, `Student_Id`, `Marks`, `Class_Exam_Name`) VALUES (@cid, @sid, @m, @clen)"
                    Dim command As New MySqlCommand(querystr, conn)

                    command.Parameters.Add("@cid", MySqlDbType.Int32).Value = class_id
                    command.Parameters.Add("@sid", MySqlDbType.Int32).Value = student_id
                    command.Parameters.Add("@m", MySqlDbType.Int32).Value = marks
                    command.Parameters.Add("@clen", MySqlDbType.VarChar).Value = class_exam_name
                    Try
                        result = command.ExecuteNonQuery()
                        If result = True Then
                            MsgBox("Add Result")
                        Else
                            MsgBox("Not Add Result")
                        End If
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    End Try
                Else
                    MsgBox("Connection error")
                End If
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles bntback.Click
        Select_Result.Show()
        Me.Show()
    End Sub

    Private Sub bntReset_Click(sender As Object, e As EventArgs) Handles bntReset.Click
        txtsid.Text = ""
        txtclassexamname.Text = ""
        txtcid.Text = ""
    End Sub

    Private Sub txtcid_TextChanged(sender As Object, e As EventArgs) Handles txtcid.TextChanged

    End Sub

    Private Sub txtcid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtcid.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtsid_TextChanged(sender As Object, e As EventArgs) Handles txtsid.TextChanged

    End Sub

    Private Sub txtsid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsid.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtmark_TextChanged(sender As Object, e As EventArgs) Handles txtmark.TextChanged

    End Sub

    Private Sub txtmark_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtmark.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub
End Class