﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Add_class_result
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.bntback = New System.Windows.Forms.Button()
        Me.txtclassexamname = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.bntReset = New System.Windows.Forms.Button()
        Me.txtmark = New System.Windows.Forms.TextBox()
        Me.txtsid = New System.Windows.Forms.TextBox()
        Me.txtcid = New System.Windows.Forms.TextBox()
        Me.bntsave = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.bntback)
        Me.Panel1.Controls.Add(Me.txtclassexamname)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.bntReset)
        Me.Panel1.Controls.Add(Me.txtmark)
        Me.Panel1.Controls.Add(Me.txtsid)
        Me.Panel1.Controls.Add(Me.txtcid)
        Me.Panel1.Controls.Add(Me.bntsave)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Location = New System.Drawing.Point(29, 32)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(795, 512)
        Me.Panel1.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(800, 80)
        Me.Panel2.TabIndex = 69
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(200, 16)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(397, 54)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Add Class Result"
        '
        'bntback
        '
        Me.bntback.BackColor = System.Drawing.Color.LightBlue
        Me.bntback.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntback.ForeColor = System.Drawing.Color.Black
        Me.bntback.Location = New System.Drawing.Point(592, 392)
        Me.bntback.Margin = New System.Windows.Forms.Padding(4)
        Me.bntback.Name = "bntback"
        Me.bntback.Size = New System.Drawing.Size(173, 56)
        Me.bntback.TabIndex = 6
        Me.bntback.Text = "Back"
        Me.bntback.UseVisualStyleBackColor = False
        '
        'txtclassexamname
        '
        Me.txtclassexamname.BackColor = System.Drawing.SystemColors.Window
        Me.txtclassexamname.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtclassexamname.Location = New System.Drawing.Point(312, 304)
        Me.txtclassexamname.Margin = New System.Windows.Forms.Padding(4)
        Me.txtclassexamname.Name = "txtclassexamname"
        Me.txtclassexamname.Size = New System.Drawing.Size(419, 34)
        Me.txtclassexamname.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(48, 304)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(225, 29)
        Me.Label3.TabIndex = 46
        Me.Label3.Text = "Class Exam Name"
        '
        'bntReset
        '
        Me.bntReset.BackColor = System.Drawing.Color.Silver
        Me.bntReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntReset.ForeColor = System.Drawing.Color.White
        Me.bntReset.Location = New System.Drawing.Point(392, 392)
        Me.bntReset.Margin = New System.Windows.Forms.Padding(4)
        Me.bntReset.Name = "bntReset"
        Me.bntReset.Size = New System.Drawing.Size(173, 56)
        Me.bntReset.TabIndex = 45
        Me.bntReset.Text = "Reset"
        Me.bntReset.UseVisualStyleBackColor = False
        '
        'txtmark
        '
        Me.txtmark.BackColor = System.Drawing.SystemColors.Window
        Me.txtmark.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmark.Location = New System.Drawing.Point(312, 247)
        Me.txtmark.Margin = New System.Windows.Forms.Padding(4)
        Me.txtmark.Name = "txtmark"
        Me.txtmark.Size = New System.Drawing.Size(419, 34)
        Me.txtmark.TabIndex = 3
        '
        'txtsid
        '
        Me.txtsid.BackColor = System.Drawing.SystemColors.Window
        Me.txtsid.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsid.Location = New System.Drawing.Point(312, 190)
        Me.txtsid.Margin = New System.Windows.Forms.Padding(4)
        Me.txtsid.Name = "txtsid"
        Me.txtsid.Size = New System.Drawing.Size(419, 34)
        Me.txtsid.TabIndex = 2
        '
        'txtcid
        '
        Me.txtcid.BackColor = System.Drawing.SystemColors.Window
        Me.txtcid.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcid.Location = New System.Drawing.Point(312, 133)
        Me.txtcid.Margin = New System.Windows.Forms.Padding(4)
        Me.txtcid.Name = "txtcid"
        Me.txtcid.Size = New System.Drawing.Size(419, 34)
        Me.txtcid.TabIndex = 1
        '
        'bntsave
        '
        Me.bntsave.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.bntsave.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntsave.ForeColor = System.Drawing.Color.White
        Me.bntsave.Location = New System.Drawing.Point(192, 392)
        Me.bntsave.Margin = New System.Windows.Forms.Padding(4)
        Me.bntsave.Name = "bntsave"
        Me.bntsave.Size = New System.Drawing.Size(173, 56)
        Me.bntsave.TabIndex = 36
        Me.bntsave.Text = "Save"
        Me.bntsave.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(48, 192)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(134, 29)
        Me.Label5.TabIndex = 35
        Me.Label5.Text = "Student ID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(48, 248)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 29)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "Mark"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(48, 136)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(110, 29)
        Me.Label6.TabIndex = 33
        Me.Label6.Text = "Class ID"
        '
        'Add_class_result
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumAquamarine
        Me.ClientSize = New System.Drawing.Size(852, 573)
        Me.Controls.Add(Me.Panel1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Add_class_result"
        Me.Text = "Add class result"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents bntReset As Button
    Friend WithEvents txtmark As TextBox
    Friend WithEvents txtsid As TextBox
    Friend WithEvents txtcid As TextBox
    Friend WithEvents bntsave As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtclassexamname As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents bntback As Button
    Friend WithEvents Panel2 As Panel
End Class
