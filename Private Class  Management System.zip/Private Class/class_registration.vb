﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions

Public Class class_registration
    Dim querystr As String
    Dim datareader As MySqlDataReader

    Private Sub class_registration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim table As New DataTable
        Dim command2 As New MySqlCommand

        Dim Teacher_Id As String
        Teacher_Id = Cmbteacher.Text
        Open_db()


        querystr = "SELECT * FROM `teacher`"
        command2.CommandText = querystr
        command2.Connection = conn

        datareader = command2.ExecuteReader
        table.Load(datareader)


        Cmbteacher.DataSource = table
        Cmbteacher.DisplayMember = "First_Name"
        Cmbteacher.ValueMember = "Teacher_Id"
    End Sub

    Private Sub Btnregster_Click(sender As Object, e As EventArgs) Handles Btnregster.Click
        Dim class_name, querystr As String
        Dim date_of_class As Date
        Dim subject_id As Integer
        Dim class_time As Integer
        Dim result As Boolean


        class_name = txtcname.Text
        'class_time = txttime.Text
        date_of_class = pdateof.Value
        class_time = txttime.Text
        subject_id = Cmbteacher.SelectedValue
        ' If empty(class_name) Or empty(date_of_class) Or empty(class_time) Or empty(subject_id) Then
        MsgBox("All Filds are Required")

        'Else

        If Open_db() Then


                querystr = "INSERT INTO `class`(`Class_Date`, `Class_Time`, `Teacher_Id`, `Class_Name`) VALUES (@cd, @ct, @ti, @cn)"
                Dim command As New MySqlCommand(querystr, conn)


                command.Parameters.Add("@cd", MySqlDbType.Date).Value = date_of_class
                command.Parameters.Add("@ct", MySqlDbType.Int32).Value = class_time
                command.Parameters.Add("@ti", MySqlDbType.Int16).Value = subject_id
                command.Parameters.Add("@cn", MySqlDbType.VarChar).Value = class_name


                Try
                    result = command.ExecuteNonQuery()

                    If result = True Then


                        MsgBox("Add class infomation")
                    Else
                        MsgBox("Not Add class infomationt")
                    End If

                Catch ex As Exception
                    MsgBox(ex.Message)



                End Try
            Else
                MsgBox("Connection error")

            End If
        ' End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles bntback.Click
        Registration_select.Show()
        Me.Hide()

    End Sub

    Private Sub Btnreset_Click(sender As Object, e As EventArgs) Handles Btnreset.Click
        txtcname.Text = ""
        txttime.Text = ""
    End Sub
End Class