﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class student_attendance
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles bntpresent.Click

        Dim date_of_class As Date
        Dim student_id, class_id As Integer
        Dim result As Boolean
        Dim querystr As String

        'date_of_class = pdate.Value
        'class_id = txtcid.Text
        'student_id = txtsid.Text
        'If empty(date_of_class) Or empty(class_id) Or empty(student_id) Then
        '    MsgBox("All Filds are Required")

        'Else

        If Open_db() Then


                querystr = "INSERT INTO `student_attendence`(`Student_Id`, `Class_Id`, `Date`) VALUES  (@sid, @cid, @date)"
                Dim command As New MySqlCommand(querystr, conn)


                command.Parameters.Add("@sid", MySqlDbType.Int32).Value = student_id
                command.Parameters.Add("@cid", MySqlDbType.Int32).Value = class_id
                command.Parameters.Add("@date", MySqlDbType.Date).Value = date_of_class



                Try
                    result = command.ExecuteNonQuery()

                    If result = True Then


                        MsgBox("Mark Attendence")
                    Else
                        MsgBox("Not Mark Attendence")
                    End If

                Catch ex As Exception
                    MsgBox(ex.Message)



                End Try
            Else
                MsgBox("Connection error")

            End If
        ' End If

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click

        txtcid.Text = ""
        txtsid.Text = ""
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        teacher_dashbord.Show()
        Me.Hide()
    End Sub

    Private Sub txtsid_TextChanged(sender As Object, e As EventArgs) Handles txtsid.TextChanged

    End Sub

    Private Sub txtsid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsid.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtcid_TextChanged(sender As Object, e As EventArgs) Handles txtcid.TextChanged

    End Sub

    Private Sub txtcid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtcid.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub
End Class