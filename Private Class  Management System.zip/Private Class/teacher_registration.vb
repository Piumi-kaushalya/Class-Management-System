﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class teacher_registration

    Private Sub Btnregster_Click(sender As Object, e As EventArgs) Handles Btnregster.Click
        Dim first_name, last_name, nic_no, email, user As String
        Dim phone_no As String
        Dim Subject As Integer
        Dim querystr As String
        Dim querystr1 As String
        Dim result As Boolean
        Dim result1 As Boolean


        first_name = Txtfulname.Text
        last_name = txtlastname.Text
        nic_no = Txtnic.Text
        email = Txtemail.Text
        Subject = Cmbsubject.SelectedValue
        phone_no = Txtpn.Text
        user = "Teacher"

        If empty(first_name) Or empty(last_name) Or empty(nic_no) Or empty(email) Or empty(Subject) Or empty(phone_no) Then
            MsgBox("All Filds are Required")

        Else
            If mobile_validation(phone_no) Then


                If Open_db() Then

                    querystr = "INSERT INTO `teacher`(`First_Name`, `Last_Name`, `NIC_No`, `Phone_No`, `Email`, `Subject`) VALUES('" & Txtfulname.Text & "', '" & txtlastname.Text & "', '" & Txtnic.Text & "', '" & Txtpn.Text & "', '" & Txtemail.Text & "', '" & Subject & "')"
                    Dim command As New MySqlCommand(querystr, conn)

                    querystr1 = "INSERT INTO `users`(`NIC_No`, `User_Role`, `Password`) VALUES ('" & Txtnic.Text & "', '" & user & "', '" & Txtpn.Text & "')"
                    Dim command1 As New MySqlCommand(querystr1, conn)



                    Try
                        result = command.ExecuteNonQuery()

                        If result = True Then


                            MsgBox("New Teacher aded")
                        Else
                            MsgBox("Not New Teacher aded")
                        End If

                    Catch ex As Exception
                        MsgBox(ex.Message)



                    End Try

                    Try
                        result1 = command1.ExecuteNonQuery()

                        If result1 = True Then


                            MsgBox("New user aded")
                        Else
                            MsgBox("Not New user aded")
                        End If

                    Catch ex As Exception
                        MsgBox(ex.Message)



                    End Try
                End If
            End If

        End If

    End Sub

    Private Sub teacher_registration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Open_db() Then

            Dim qury1 As String
            Dim da1 As New MySqlDataAdapter
            Dim dt1 As New DataTable


            qury1 = "SELECT * FROM `subjects`"
            da1.SelectCommand = New MySqlCommand(qury1, conn)
            da1.Fill(dt1)
            Cmbsubject.DataSource = dt1
            Cmbsubject.DisplayMember = "Subject_Name"
            Cmbsubject.ValueMember = "Subject_Id"


        Else
            MsgBox("Connection Fails")

        End If
    End Sub



    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Registration_select.Show()
        Me.Hide()

    End Sub

    Private Sub Btnreset_Click(sender As Object, e As EventArgs) Handles Btnreset.Click
        txtlastname.Text = ""
        Txtemail.Text = ""
        Txtfulname.Text = ""
        Txtnic.Text = ""
        Txtpn.Text = ""
    End Sub

    Private Sub Txtfulname_TextChanged(sender As Object, e As EventArgs) Handles Txtfulname.TextChanged

    End Sub

    Private Sub Txtfulname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txtfulname.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtlastname_TextChanged(sender As Object, e As EventArgs) Handles txtlastname.TextChanged

    End Sub

    Private Sub txtlastname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtlastname.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Txtnic_TextChanged(sender As Object, e As EventArgs) Handles Txtnic.TextChanged

    End Sub

    Private Sub Txtpn_TextChanged(sender As Object, e As EventArgs) Handles Txtpn.TextChanged

    End Sub

    Private Sub Txtpn_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txtpn.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If

    End Sub

    Private Sub Txtemail_TextChanged(sender As Object, e As EventArgs) Handles Txtemail.TextChanged

    End Sub

    Private Sub Txtemail_Leave(sender As Object, e As EventArgs) Handles Txtemail.Leave
        Dim pattern As String
        pattern = "^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"
        If Not Regex.IsMatch(Txtemail.Text, pattern) Then
            Txtemail.Focus()
            MsgBox("Not a valid Email address ")
            Return
        End If
    End Sub
End Class