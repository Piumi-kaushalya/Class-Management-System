﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions

Public Class student_registration
    Dim querystr As String
    Dim datareader As MySqlDataReader

    Private Sub student_registration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim table As New DataTable
        Dim command2 As New MySqlCommand

        Dim Parents_Id As String
        Parents_Id = Cmbpid.Text
        Open_db()


        querystr = "SELECT * FROM `parents`"
        command2.CommandText = querystr
        command2.Connection = conn

        datareader = command2.ExecuteReader
        table.Load(datareader)


        Cmbpid.DataSource = table
        Cmbpid.DisplayMember = "Parents_Id"
        Cmbpid.ValueMember = "Parents_Id"
    End Sub

    Private Sub Btnregister_Click(sender As Object, e As EventArgs) Handles Btnregister.Click
        Dim parent_id As Integer
        Dim first_name, last_name, street, city, school, querystr As String
        Dim date_of_birth As Date
        '  Dim gender As Integer
        Dim result As Boolean





        parent_id = Cmbpid.SelectedValue
        first_name = Txtfname.Text
        last_name = Txtlname.Text
        city = Txtcity.Text
        street = Txtstreet.Text
        school = Txtschool.Text
        date_of_birth = DTPbirth.Value
        ' gender = Rbtnmale.Checked
        If empty(first_name) Or empty(last_name) Or empty(city) Or empty(street) Or empty(school) Then
            MsgBox("All Fields Are Required!")
        Else

            If Open_db() Then

                querystr = "INSERT INTO `students`(`Parent_Id`, `First_Name`, `Last_Name`, `Street`, `City`, `School`, `Date_Of_Birth`, `Gender`) VALUES (@PID, @FN, @LN, @STREET, @CITY, @SCH, @BIRTH, @GENDER)"
                Dim command As New MySqlCommand(querystr, conn)

                command.Parameters.Add("@PID", MySqlDbType.Int32).Value = parent_id
                command.Parameters.Add("@FN", MySqlDbType.VarChar).Value = first_name
                command.Parameters.Add("@LN", MySqlDbType.VarChar).Value = last_name
                command.Parameters.Add("@STREET", MySqlDbType.VarChar).Value = street
                command.Parameters.Add("@CITY", MySqlDbType.VarChar).Value = city
                command.Parameters.Add("@SCH", MySqlDbType.VarChar).Value = school
                command.Parameters.Add("@BIRTH", MySqlDbType.Date).Value = date_of_birth

                Dim gender As String = ""
                If Rbtnmale.Checked = True Then
                    gender = "male"
                Else
                    If Rbtnfemale.Checked = True Then
                        gender = "female"

                    End If
                End If

                command.Parameters.Add("@GENDER", MySqlDbType.VarChar).Value = gender

                Try
                    result = command.ExecuteNonQuery()

                    If result = True Then
                        MsgBox("New student resgister")

                    Else
                        MsgBox("Not new student resgister")

                    End If



                Catch ex As Exception
                    MsgBox(ex.Message)


                End Try
            Else

                MsgBox("Connection error")
            End If
        End If

    End Sub

    Private Sub Btnreset_Click(sender As Object, e As EventArgs) Handles Btnreset.Click
        'Cmbpid.SelectedValue = ""
        Txtfname.Text = ""
        Txtlname.Text = ""
        Txtcity.Text = ""
        Txtstreet.Text = ""
        Txtschool.Text = ""
        'DTPbirth.Value = ""
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Registration_select.Show()
        Me.Hide()

    End Sub

    Private Sub Txtfname_TextChanged(sender As Object, e As EventArgs) Handles Txtfname.TextChanged

    End Sub

    Private Sub Txtfname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txtfname.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Txtlname_TextChanged(sender As Object, e As EventArgs) Handles Txtlname.TextChanged

    End Sub

    Private Sub Txtlname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txtlname.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Txtstreet_TextChanged(sender As Object, e As EventArgs) Handles Txtstreet.TextChanged

    End Sub

    Private Sub Txtstreet_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txtstreet.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Txtcity_TextChanged(sender As Object, e As EventArgs) Handles Txtcity.TextChanged

    End Sub

    Private Sub Txtcity_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txtcity.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Txtschool_TextChanged(sender As Object, e As EventArgs) Handles Txtschool.TextChanged

    End Sub

    Private Sub Txtschool_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txtschool.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub
End Class
