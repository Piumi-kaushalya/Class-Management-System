﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class Student_enter_Class
    Private Sub st_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Open_db() Then

            Dim qury1 As String
            Dim da1 As New MySqlDataAdapter
            Dim dt1 As New DataTable


            qury1 = "SELECT * FROM `class`"
            da1.SelectCommand = New MySqlCommand(qury1, conn)
            da1.Fill(dt1)
            cmbclass.DataSource = dt1
            cmbclass.DisplayMember = "Class_Name"
            cmbclass.ValueMember = "Class_Id"


        Else
            MsgBox("Connection Fails")

        End If
    End Sub

    Private Sub bntok_Click(sender As Object, e As EventArgs) Handles bntok.Click
        Dim class_Id As String
        Dim student_id As Integer
        Dim querystr As String
        Dim result As Boolean


        class_Id = cmbclass.SelectedValue
        student_id = txtstid.Text
        'If empty(class_Id) Or empty(student_id) Then
        '    MsgBox("All Filds are Required")

        'Else



        If Open_db() Then


                querystr = "INSERT INTO `student_class`(`Class_Id`, `Student_Id`) VALUES ('" & class_Id & "', '" & student_id & "')"
                Dim command As New MySqlCommand(querystr, conn)

                Try
                    result = command.ExecuteNonQuery()

                    If result = True Then


                    MsgBox("Add ")
                Else
                    MsgBox("Not Add ")
                End If

                Catch ex As Exception
                    MsgBox(ex.Message)



                End Try
            Else
                MsgBox("Connection error")

            End If
        'End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Registration_select.Show()
        Me.Hide()

    End Sub

    Private Sub Bntrest_Click(sender As Object, e As EventArgs) Handles Bntrest.Click
        txtstid.Text = ""

    End Sub

    Private Sub txtstid_TextChanged(sender As Object, e As EventArgs) Handles txtstid.TextChanged

    End Sub

    Private Sub txtstid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtstid.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub
End Class