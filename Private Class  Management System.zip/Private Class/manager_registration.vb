﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class manager_registration
    Private Sub Btnregster_Click(sender As Object, e As EventArgs) Handles Btnregster.Click

        Dim first_name, last_name, nic_no, email, user As String
        Dim phone_no As String
        Dim querystr As String
        Dim querystr1 As String
        Dim result As Boolean
        Dim result1 As Boolean


        first_name = Txtfname.Text
        last_name = txtlaname.Text
        nic_no = Txtnic.Text
        email = Txtemail.Text

        phone_no = Txtphone.Text
        user = "Manager"


        'If empty(first_name) Or empty(last_name) Or empty(nic_no) Or empty(email) Or empty(phone_no) Or empty(user) Then
        '    MsgBox("All Filds are Required")

        'Else


        If mobile_validation(phone_no) Then


            If Open_db() Then

                querystr = "INSERT INTO `manager_registration`(`First_Name`, `Last_Name`, `NIC_No`, `Phone_No`, `Email`) VALUES('" & Txtfname.Text & "', '" & txtlaname.Text & "', '" & Txtnic.Text & "', '" & Txtphone.Text & "', '" & Txtemail.Text & "')"
                Dim command As New MySqlCommand(querystr, conn)

                querystr1 = "INSERT INTO `users`(`NIC_No`, `User_Role`, `Password`) VALUES ('" & Txtnic.Text & "', '" & user & "', '" & Txtphone.Text & "')"
                Dim command1 As New MySqlCommand(querystr1, conn)



                Try
                    result = command.ExecuteNonQuery()

                    If result = True Then


                        MsgBox("New Manager aded")
                    Else
                        MsgBox("Not New manager aded")
                    End If

                Catch ex As Exception
                    MsgBox(ex.Message)


                    'manager_reg''''
                End Try

                Try
                    result1 = command1.ExecuteNonQuery()

                    If result1 = True Then


                        MsgBox("New user aded")
                    Else
                        MsgBox("Not New user aded")
                    End If

                Catch ex As Exception
                    MsgBox(ex.Message)

                End Try
            End If
        End If
    End Sub



    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        admin.Show()
        Me.Hide()

    End Sub


    Private Sub Txtfname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txtfname.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Txtfname_TextChanged(sender As Object, e As EventArgs) Handles Txtfname.TextChanged

    End Sub

    Private Sub txtlaname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtlaname.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Txtemail_TextChanged(sender As Object, e As EventArgs) Handles Txtemail.TextChanged

    End Sub

    Private Sub Txtemail_Leave(sender As Object, e As EventArgs) Handles Txtemail.Leave
        Dim pattern As String
        pattern = "^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"
        If Not Regex.IsMatch(Txtemail.Text, pattern) Then
            Txtemail.Focus()
            MsgBox("Not a valid Email address ")
            Return
        End If
    End Sub

    Private Sub Txtphone_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txtphone.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Btnreset_Click(sender As Object, e As EventArgs) Handles Btnreset.Click
        txtlaname.Text = ""
        Txtemail.Text = ""
        Txtfname.Text = ""
        Txtphone.Text = ""
        Txtnic.Text = ""

    End Sub
End Class