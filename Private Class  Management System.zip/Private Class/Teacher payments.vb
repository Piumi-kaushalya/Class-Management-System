﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class Teacher_patment


    Private Sub bntpament_Click(sender As Object, e As EventArgs) Handles bntpament.Click
        Dim discription, querystr As String
        Dim teacher_id As Integer
        Dim amount As Double
        Dim paid_date As Date
        Dim result As Boolean

        discription = txtdis.Text
        teacher_id = txttid.Text
        amount = txtamount.Text
        paid_date = dtpfrom.Value

        If Open_db() Then


            querystr = "INSERT INTO `teacher_payments`(`Teacher_Id`, `Amount`, `discription`, `paid_date`) VALUES (@TID, @AMOUNT, @DIS, @D)"
            Dim command As New MySqlCommand(querystr, conn)
            command.Parameters.Add("@TID", MySqlDbType.Int32).Value = teacher_id
            command.Parameters.Add("@D", MySqlDbType.Date).Value = paid_date
            command.Parameters.Add("@AMOUNT", MySqlDbType.Int32).Value = amount
            command.Parameters.Add("@DIS", MySqlDbType.VarChar).Value = discription

            Try
                result = command.ExecuteNonQuery()

                If result = True Then


                    MsgBox("Add payment")
                Else
                    MsgBox("Not Add payment")
                End If

            Catch ex As Exception
                MsgBox(ex.Message)



            End Try
        Else
            MsgBox("Connection error")

        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Finance.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        txtamount.Text = ""
        txtdis.Text = ""
        txttid.Text = ""

    End Sub

    Private Sub txttid_TextChanged(sender As Object, e As EventArgs) Handles txttid.TextChanged

    End Sub

    Private Sub txttid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txttid.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtamount_TextChanged(sender As Object, e As EventArgs) Handles txtamount.TextChanged

    End Sub

    Private Sub txtamount_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtamount.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub
End Class