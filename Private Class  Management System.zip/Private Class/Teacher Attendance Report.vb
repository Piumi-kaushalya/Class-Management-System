﻿Imports MySql.Data.MySqlClient
Public Class Teacher_Attendance_Report
    Dim command As New MySqlCommand
    Dim datareader As MySqlDataReader
    Dim querystr As String
    Dim table As New DataTable
    Private Sub Teacher_Attendance_Report_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Open_db() Then


            querystr = "SELECT `Teacher_Attendence_Id`, `Teacher_Id`, `Class_Id`, `Pay_Date` FROM `teacher_attendence`"
            command.CommandText = querystr
            command.Connection = conn

            datareader = command.ExecuteReader

            table.Load(datareader)

            gridattendance.DataSource = table
            With gridattendance
                .Columns(0).HeaderText = "Teacher_Attendence_Id"
                .Columns(1).HeaderText = "Teacher_Id"
                .Columns(2).HeaderText = "Class_Id"
                .Columns(3).HeaderText = "Pay_Date"

                '.Columns(4).HeaderText = "Date"
                .Columns(0).Visible = False
            End With




        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Manager_Reports.Show()
        Me.Hide()

    End Sub
End Class