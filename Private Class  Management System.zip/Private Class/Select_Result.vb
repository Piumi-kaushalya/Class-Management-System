﻿Public Class Select_Result
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Add_Ol_result.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Add_AL_Result.Show()
        Me.Hide()

    End Sub

    Private Sub bntst_attendence_Click(sender As Object, e As EventArgs) Handles bntst_attendence.Click
        Add_class_result.Show()
        Me.Hide()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles bntback.Click
        teacher_dashbord.Show()
        Me.Hide()
    End Sub
End Class