﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions

Public Class Expences


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Water_bill, electricity_bill, rent, phone_bill, advertising As Double
        Dim pay_date As Date
        Dim str As String
        Dim result As Boolean


        Water_bill = txtwater.Text
        electricity_bill = txtelec.Text
        rent = txtrent.Text
        phone_bill = txtphonebill.Text
        advertising = txtad.Text
        pay_date = pdate.Value
        'If empty(Water_bill) Or empty(electricity_bill) Or empty(rent) Or empty(phone_bill) Or empty(advertising) Or empty(pay_date) Then
        '    MsgBox("All Filds are Required")

        'Else



        If Open_db() Then


                str = "INSERT INTO `expensess`(`Water_bill`, `Eleyicity_bill`, `Rent`, `Phone_bill`, `Advertising`, `Paid_Date`) VALUES (@WB, @EB, @R, @PHONE, @AD, @PDATE)"
                Dim command As New MySqlCommand(str, conn)

                command.Parameters.Add("@WB", MySqlDbType.Double).Value = Water_bill
                command.Parameters.Add("@EB", MySqlDbType.Double).Value = electricity_bill
                command.Parameters.Add("@R", MySqlDbType.Double).Value = rent
                command.Parameters.Add("@PHONE", MySqlDbType.Double).Value = phone_bill
                command.Parameters.Add("@AD", MySqlDbType.Double).Value = advertising
                command.Parameters.Add("@PDATE", MySqlDbType.Date).Value = pay_date

                Try
                    result = command.ExecuteNonQuery()

                    If result = True Then


                    MsgBox("Added Expences")
                Else
                    MsgBox("Not Add Expences")
                End If

                Catch ex As Exception
                    MsgBox(ex.Message)



                End Try
            Else
                MsgBox("Connection error")

            End If
        'End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Finance.Show()
        Me.Hide()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txtad.Text = ""
        txtelec.Text = ""
        txtphonebill.Text = ""
        txtrent.Text = ""
        txtwater.Text = ""

    End Sub

    Private Sub txtwater_TextChanged(sender As Object, e As EventArgs) Handles txtwater.TextChanged

    End Sub

    Private Sub txtwater_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtwater.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtelec_TextChanged(sender As Object, e As EventArgs) Handles txtelec.TextChanged

    End Sub

    Private Sub txtelec_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtelec.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtrent_TextChanged(sender As Object, e As EventArgs) Handles txtrent.TextChanged

    End Sub

    Private Sub txtrent_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtrent.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtphonebill_TextChanged(sender As Object, e As EventArgs) Handles txtphonebill.TextChanged

    End Sub

    Private Sub txtphonebill_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtphonebill.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtad_TextChanged(sender As Object, e As EventArgs) Handles txtad.TextChanged

    End Sub

    Private Sub txtad_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtad.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub
End Class