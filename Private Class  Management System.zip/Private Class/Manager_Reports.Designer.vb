﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Manager_Reports
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.bntpd = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.bntsa = New System.Windows.Forms.Button()
        Me.bntsd = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.bnttpa = New System.Windows.Forms.Button()
        Me.bntcr = New System.Windows.Forms.Button()
        Me.bntcd = New System.Windows.Forms.Button()
        Me.bntback = New System.Windows.Forms.Button()
        Me.bntta = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'bntpd
        '
        Me.bntpd.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntpd.FlatAppearance.BorderSize = 5
        Me.bntpd.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntpd.Location = New System.Drawing.Point(40, 64)
        Me.bntpd.Name = "bntpd"
        Me.bntpd.Size = New System.Drawing.Size(352, 48)
        Me.bntpd.TabIndex = 3
        Me.bntpd.Text = "Parent Details"
        Me.bntpd.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Button3.FlatAppearance.BorderSize = 5
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(40, 304)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(352, 48)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "Teacher  details"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'bntsa
        '
        Me.bntsa.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntsa.FlatAppearance.BorderSize = 5
        Me.bntsa.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntsa.Location = New System.Drawing.Point(40, 224)
        Me.bntsa.Name = "bntsa"
        Me.bntsa.Size = New System.Drawing.Size(352, 48)
        Me.bntsa.TabIndex = 6
        Me.bntsa.Text = "student Attendance"
        Me.bntsa.UseVisualStyleBackColor = False
        '
        'bntsd
        '
        Me.bntsd.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntsd.FlatAppearance.BorderSize = 5
        Me.bntsd.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntsd.Location = New System.Drawing.Point(40, 144)
        Me.bntsd.Name = "bntsd"
        Me.bntsd.Size = New System.Drawing.Size(352, 48)
        Me.bntsd.TabIndex = 5
        Me.bntsd.Text = "Student  Details"
        Me.bntsd.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(24, 32)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(872, 72)
        Me.Panel1.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(224, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(283, 44)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Select Reports"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel2.Controls.Add(Me.bntta)
        Me.Panel2.Controls.Add(Me.bnttpa)
        Me.Panel2.Controls.Add(Me.bntcr)
        Me.Panel2.Controls.Add(Me.bntcd)
        Me.Panel2.Controls.Add(Me.bntback)
        Me.Panel2.Controls.Add(Me.bntpd)
        Me.Panel2.Controls.Add(Me.Button3)
        Me.Panel2.Controls.Add(Me.bntsa)
        Me.Panel2.Controls.Add(Me.bntsd)
        Me.Panel2.Location = New System.Drawing.Point(24, 104)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(872, 512)
        Me.Panel2.TabIndex = 10
        '
        'bnttpa
        '
        Me.bnttpa.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bnttpa.FlatAppearance.BorderSize = 5
        Me.bnttpa.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bnttpa.Location = New System.Drawing.Point(472, 144)
        Me.bnttpa.Name = "bnttpa"
        Me.bnttpa.Size = New System.Drawing.Size(352, 48)
        Me.bnttpa.TabIndex = 72
        Me.bnttpa.Text = "Teacher Payments"
        Me.bnttpa.UseVisualStyleBackColor = False
        '
        'bntcr
        '
        Me.bntcr.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntcr.FlatAppearance.BorderSize = 5
        Me.bntcr.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntcr.Location = New System.Drawing.Point(472, 224)
        Me.bntcr.Name = "bntcr"
        Me.bntcr.Size = New System.Drawing.Size(352, 48)
        Me.bntcr.TabIndex = 71
        Me.bntcr.Text = "Class Result"
        Me.bntcr.UseVisualStyleBackColor = False
        '
        'bntcd
        '
        Me.bntcd.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntcd.FlatAppearance.BorderSize = 5
        Me.bntcd.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntcd.Location = New System.Drawing.Point(472, 304)
        Me.bntcd.Name = "bntcd"
        Me.bntcd.Size = New System.Drawing.Size(352, 48)
        Me.bntcd.TabIndex = 70
        Me.bntcd.Text = "Class Details"
        Me.bntcd.UseVisualStyleBackColor = False
        '
        'bntback
        '
        Me.bntback.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.bntback.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntback.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.bntback.Location = New System.Drawing.Point(344, 400)
        Me.bntback.Margin = New System.Windows.Forms.Padding(4)
        Me.bntback.Name = "bntback"
        Me.bntback.Size = New System.Drawing.Size(192, 56)
        Me.bntback.TabIndex = 69
        Me.bntback.Text = "Back"
        Me.bntback.UseVisualStyleBackColor = False
        '
        'bntta
        '
        Me.bntta.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntta.FlatAppearance.BorderSize = 5
        Me.bntta.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntta.Location = New System.Drawing.Point(472, 64)
        Me.bntta.Name = "bntta"
        Me.bntta.Size = New System.Drawing.Size(352, 48)
        Me.bntta.TabIndex = 73
        Me.bntta.Text = "Teacher  Attendance"
        Me.bntta.UseVisualStyleBackColor = False
        '
        'Manager_Reports
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumAquamarine
        Me.ClientSize = New System.Drawing.Size(923, 641)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Name = "Manager_Reports"
        Me.Text = "Manager_Reports"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents bntpd As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents bntsa As Button
    Friend WithEvents bntsd As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents bntback As Button
    Friend WithEvents bnttpa As Button
    Friend WithEvents bntcr As Button
    Friend WithEvents bntcd As Button
    Friend WithEvents bntta As Button
End Class
