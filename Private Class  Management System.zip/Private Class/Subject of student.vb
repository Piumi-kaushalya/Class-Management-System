﻿Public Class Subject_of_student

End Class