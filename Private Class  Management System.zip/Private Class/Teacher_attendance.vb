﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions

Public Class Teacher_attendance
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim date_of_class As Date
        Dim teacher_id, class_id As Integer
        Dim result As Boolean
        Dim querystr As String

        date_of_class = pdate.Value
        class_id = txtcid.Text
        teacher_id = txttid.Text


        If Open_db() Then


            querystr = "INSERT INTO `teacher_attendence`(`Teacher_Id`, `Class_Id`, `Pay_Date`) VALUES (@tid, @cid, @date)"
            Dim command As New MySqlCommand(querystr, conn)


            command.Parameters.Add("@tid", MySqlDbType.Int32).Value = teacher_id
            command.Parameters.Add("@cid", MySqlDbType.Int32).Value = class_id
            command.Parameters.Add("@date", MySqlDbType.Date).Value = date_of_class



            Try
                result = command.ExecuteNonQuery()

                If result = True Then


                    MsgBox("mark attendance")
                Else
                    MsgBox("Not mark")
                End If

            Catch ex As Exception
                MsgBox(ex.Message)



            End Try
        Else
            MsgBox("Connection error")

        End If


    End Sub

    Private Sub txttid_TextChanged(sender As Object, e As EventArgs) Handles txttid.TextChanged

    End Sub

    Private Sub txttid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txttid.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtcid_TextChanged(sender As Object, e As EventArgs) Handles txtcid.TextChanged

    End Sub

    Private Sub txtcid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtcid.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub bntback_Click(sender As Object, e As EventArgs) Handles bntback.Click
        view_Reports.Show()
        Me.Hide()

    End Sub
End Class