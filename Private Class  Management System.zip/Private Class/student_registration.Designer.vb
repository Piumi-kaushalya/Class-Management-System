﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class student_registration
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.BackgroundWorker2 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.DTPbirth = New System.Windows.Forms.DateTimePicker()
        Me.Txtstreet = New System.Windows.Forms.TextBox()
        Me.Txtcity = New System.Windows.Forms.TextBox()
        Me.Txtlname = New System.Windows.Forms.TextBox()
        Me.Txtfname = New System.Windows.Forms.TextBox()
        Me.Btnregister = New System.Windows.Forms.Button()
        Me.Rbtnmale = New System.Windows.Forms.RadioButton()
        Me.Rbtnfemale = New System.Windows.Forms.RadioButton()
        Me.Btnreset = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Txtschool = New System.Windows.Forms.TextBox()
        Me.Cmbpid = New System.Windows.Forms.ComboBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(24, 24)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(760, 71)
        Me.Panel1.TabIndex = 8
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(154, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(401, 46)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Student Registration"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(96, 112)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(141, 29)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "First Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(96, 224)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 29)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Street"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(96, 77)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(0, 29)
        Me.Label5.TabIndex = 4
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(96, 168)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(137, 29)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Last Name"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(468, 149)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(0, 25)
        Me.Label7.TabIndex = 6
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(96, 440)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(100, 29)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Gender"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(96, 336)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(94, 29)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "School"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(96, 384)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(160, 29)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Date Of birth"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(96, 288)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(57, 29)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "City"
        '
        'DTPbirth
        '
        Me.DTPbirth.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DTPbirth.Location = New System.Drawing.Point(272, 392)
        Me.DTPbirth.Name = "DTPbirth"
        Me.DTPbirth.Size = New System.Drawing.Size(393, 30)
        Me.DTPbirth.TabIndex = 7
        '
        'Txtstreet
        '
        Me.Txtstreet.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtstreet.Location = New System.Drawing.Point(272, 224)
        Me.Txtstreet.Name = "Txtstreet"
        Me.Txtstreet.Size = New System.Drawing.Size(393, 30)
        Me.Txtstreet.TabIndex = 4
        '
        'Txtcity
        '
        Me.Txtcity.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtcity.Location = New System.Drawing.Point(272, 280)
        Me.Txtcity.Name = "Txtcity"
        Me.Txtcity.Size = New System.Drawing.Size(393, 30)
        Me.Txtcity.TabIndex = 5
        '
        'Txtlname
        '
        Me.Txtlname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtlname.Location = New System.Drawing.Point(272, 168)
        Me.Txtlname.Name = "Txtlname"
        Me.Txtlname.Size = New System.Drawing.Size(393, 30)
        Me.Txtlname.TabIndex = 3
        '
        'Txtfname
        '
        Me.Txtfname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtfname.Location = New System.Drawing.Point(272, 112)
        Me.Txtfname.Name = "Txtfname"
        Me.Txtfname.Size = New System.Drawing.Size(393, 30)
        Me.Txtfname.TabIndex = 2
        '
        'Btnregister
        '
        Me.Btnregister.BackColor = System.Drawing.Color.CornflowerBlue
        Me.Btnregister.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnregister.ForeColor = System.Drawing.Color.White
        Me.Btnregister.Location = New System.Drawing.Point(184, 512)
        Me.Btnregister.Name = "Btnregister"
        Me.Btnregister.Size = New System.Drawing.Size(148, 60)
        Me.Btnregister.TabIndex = 10
        Me.Btnregister.Text = "Register"
        Me.Btnregister.UseVisualStyleBackColor = False
        '
        'Rbtnmale
        '
        Me.Rbtnmale.AutoSize = True
        Me.Rbtnmale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rbtnmale.Location = New System.Drawing.Point(312, 456)
        Me.Rbtnmale.Name = "Rbtnmale"
        Me.Rbtnmale.Size = New System.Drawing.Size(80, 29)
        Me.Rbtnmale.TabIndex = 8
        Me.Rbtnmale.TabStop = True
        Me.Rbtnmale.Text = "Male"
        Me.Rbtnmale.UseVisualStyleBackColor = True
        '
        'Rbtnfemale
        '
        Me.Rbtnfemale.AutoSize = True
        Me.Rbtnfemale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rbtnfemale.Location = New System.Drawing.Point(448, 456)
        Me.Rbtnfemale.Name = "Rbtnfemale"
        Me.Rbtnfemale.Size = New System.Drawing.Size(104, 29)
        Me.Rbtnfemale.TabIndex = 9
        Me.Rbtnfemale.TabStop = True
        Me.Rbtnfemale.Text = "Female"
        Me.Rbtnfemale.UseVisualStyleBackColor = True
        '
        'Btnreset
        '
        Me.Btnreset.BackColor = System.Drawing.Color.Silver
        Me.Btnreset.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnreset.ForeColor = System.Drawing.Color.White
        Me.Btnreset.Location = New System.Drawing.Point(364, 512)
        Me.Btnreset.Name = "Btnreset"
        Me.Btnreset.Size = New System.Drawing.Size(148, 60)
        Me.Btnreset.TabIndex = 11
        Me.Btnreset.Text = "Reset"
        Me.Btnreset.UseVisualStyleBackColor = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(96, 56)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(118, 29)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "Parent Id"
        '
        'Txtschool
        '
        Me.Txtschool.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtschool.Location = New System.Drawing.Point(272, 336)
        Me.Txtschool.Name = "Txtschool"
        Me.Txtschool.Size = New System.Drawing.Size(393, 30)
        Me.Txtschool.TabIndex = 6
        '
        'Cmbpid
        '
        Me.Cmbpid.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmbpid.FormattingEnabled = True
        Me.Cmbpid.Location = New System.Drawing.Point(272, 56)
        Me.Cmbpid.Name = "Cmbpid"
        Me.Cmbpid.Size = New System.Drawing.Size(393, 33)
        Me.Cmbpid.TabIndex = 25
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.Button6)
        Me.Panel2.Controls.Add(Me.Cmbpid)
        Me.Panel2.Controls.Add(Me.Txtschool)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Btnreset)
        Me.Panel2.Controls.Add(Me.Rbtnfemale)
        Me.Panel2.Controls.Add(Me.Rbtnmale)
        Me.Panel2.Controls.Add(Me.Btnregister)
        Me.Panel2.Controls.Add(Me.Txtfname)
        Me.Panel2.Controls.Add(Me.Txtlname)
        Me.Panel2.Controls.Add(Me.Txtcity)
        Me.Panel2.Controls.Add(Me.Txtstreet)
        Me.Panel2.Controls.Add(Me.DTPbirth)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Location = New System.Drawing.Point(24, 92)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(763, 620)
        Me.Panel2.TabIndex = 9
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.LightBlue
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.Black
        Me.Button6.Location = New System.Drawing.Point(544, 512)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(148, 60)
        Me.Button6.TabIndex = 70
        Me.Button6.Text = "Back"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'student_registration
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumAquamarine
        Me.ClientSize = New System.Drawing.Size(822, 736)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "student_registration"
        Me.Text = "Form1"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BackgroundWorker2 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents DTPbirth As DateTimePicker
    Friend WithEvents Txtstreet As TextBox
    Friend WithEvents Txtcity As TextBox
    Friend WithEvents Txtlname As TextBox
    Friend WithEvents Txtfname As TextBox
    Friend WithEvents Btnregister As Button
    Friend WithEvents Rbtnmale As RadioButton
    Friend WithEvents Rbtnfemale As RadioButton
    Friend WithEvents Btnreset As Button
    Friend WithEvents Label12 As Label
    Friend WithEvents Txtschool As TextBox
    Friend WithEvents Cmbpid As ComboBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button6 As Button
End Class
