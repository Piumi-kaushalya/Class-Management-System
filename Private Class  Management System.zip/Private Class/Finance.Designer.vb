﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Finance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.bntadd = New System.Windows.Forms.Button()
        Me.bntprofit = New System.Windows.Forms.Button()
        Me.bntincome = New System.Windows.Forms.Button()
        Me.bnttpay = New System.Windows.Forms.Button()
        Me.bntst = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.bntback = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'bntadd
        '
        Me.bntadd.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntadd.FlatAppearance.BorderSize = 5
        Me.bntadd.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntadd.Location = New System.Drawing.Point(200, 48)
        Me.bntadd.Name = "bntadd"
        Me.bntadd.Size = New System.Drawing.Size(352, 48)
        Me.bntadd.TabIndex = 1
        Me.bntadd.Text = "Add Expences"
        Me.bntadd.UseVisualStyleBackColor = False
        '
        'bntprofit
        '
        Me.bntprofit.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntprofit.FlatAppearance.BorderSize = 5
        Me.bntprofit.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntprofit.Location = New System.Drawing.Point(200, 368)
        Me.bntprofit.Name = "bntprofit"
        Me.bntprofit.Size = New System.Drawing.Size(352, 48)
        Me.bntprofit.TabIndex = 2
        Me.bntprofit.Text = "Profit"
        Me.bntprofit.UseVisualStyleBackColor = False
        '
        'bntincome
        '
        Me.bntincome.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntincome.FlatAppearance.BorderSize = 5
        Me.bntincome.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntincome.Location = New System.Drawing.Point(200, 288)
        Me.bntincome.Name = "bntincome"
        Me.bntincome.Size = New System.Drawing.Size(352, 48)
        Me.bntincome.TabIndex = 4
        Me.bntincome.Text = "Income"
        Me.bntincome.UseVisualStyleBackColor = False
        '
        'bnttpay
        '
        Me.bnttpay.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bnttpay.FlatAppearance.BorderSize = 5
        Me.bnttpay.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bnttpay.Location = New System.Drawing.Point(200, 208)
        Me.bnttpay.Name = "bnttpay"
        Me.bnttpay.Size = New System.Drawing.Size(352, 48)
        Me.bnttpay.TabIndex = 6
        Me.bnttpay.Text = "Teache payments"
        Me.bnttpay.UseVisualStyleBackColor = False
        '
        'bntst
        '
        Me.bntst.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.bntst.FlatAppearance.BorderSize = 5
        Me.bntst.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntst.Location = New System.Drawing.Point(200, 128)
        Me.bntst.Name = "bntst"
        Me.bntst.Size = New System.Drawing.Size(352, 48)
        Me.bntst.TabIndex = 5
        Me.bntst.Text = "Student Fees"
        Me.bntst.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(24, 24)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(754, 56)
        Me.Panel1.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(264, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(162, 44)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Finance"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel2.Controls.Add(Me.bntback)
        Me.Panel2.Controls.Add(Me.bntadd)
        Me.Panel2.Controls.Add(Me.bntprofit)
        Me.Panel2.Controls.Add(Me.bntincome)
        Me.Panel2.Controls.Add(Me.bnttpay)
        Me.Panel2.Controls.Add(Me.bntst)
        Me.Panel2.Location = New System.Drawing.Point(24, 80)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(754, 520)
        Me.Panel2.TabIndex = 10
        '
        'bntback
        '
        Me.bntback.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.bntback.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntback.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.bntback.Location = New System.Drawing.Point(360, 448)
        Me.bntback.Margin = New System.Windows.Forms.Padding(4)
        Me.bntback.Name = "bntback"
        Me.bntback.Size = New System.Drawing.Size(192, 56)
        Me.bntback.TabIndex = 69
        Me.bntback.Text = "Back"
        Me.bntback.UseVisualStyleBackColor = False
        '
        'Finance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumAquamarine
        Me.ClientSize = New System.Drawing.Size(804, 625)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Name = "Finance"
        Me.Text = "Finance"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents bntadd As Button
    Friend WithEvents bntprofit As Button
    Friend WithEvents bntincome As Button
    Friend WithEvents bnttpay As Button
    Friend WithEvents bntst As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents bntback As Button
End Class
