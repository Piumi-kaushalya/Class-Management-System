﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class Add_AL_Result
    Dim querystr As String
    Dim datareader As MySqlDataReader
    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Open_db() Then

            Dim qury1, qury2, qury3 As String
            Dim da1, da2, da3 As New MySqlDataAdapter
            Dim dt1, dt2, dt3 As New DataTable

            qury1 = "SELECT * FROM subjects"
            da1.SelectCommand = New MySqlCommand(qury1, conn)
            da1.Fill(dt1)
            cmbsub1.DataSource = dt1
            cmbsub1.DisplayMember = "Subject_Name"
            cmbsub1.ValueMember = "Subject_Id"

            qury2 = "SELECT * FROM subjects"
            da2.SelectCommand = New MySqlCommand(qury2, conn)
            da2.Fill(dt2)
            cmbsub2.DataSource = dt2
            cmbsub2.DisplayMember = "Subject_Name"
            cmbsub2.ValueMember = "Subject_Id"

            qury3 = "SELECT * FROM subjects"
            da3.SelectCommand = New MySqlCommand(qury3, conn)
            da3.Fill(dt3)
            cmbsub3.DataSource = dt3
            cmbsub3.DisplayMember = "Subject_Name"
            cmbsub3.ValueMember = "Subject_Id"


        Else
            MsgBox("Connection Fails")
        End If
    End Sub

    Private Sub bntsave_Click(sender As Object, e As EventArgs) Handles bntsave.Click
        Dim year, attempt, result1, result2, result3, querystr As String
        Dim subject1, subject2, subject3 As String
        Dim student_id As Integer
        Dim result As Boolean

        student_id = txtsid.Text
        year = txtyear.Text
        attempt = Cmbattemp.SelectedIndex
        result1 = txtresult1.Text
        result2 = txtresult2.Text
        result3 = txtresuilt3.Text
        subject1 = cmbsub1.SelectedValue
        subject2 = cmbsub2.SelectedValue
        subject3 = cmbsub3.SelectedValue

        If empty(student_id) Or empty(year) Or empty(attempt) Or empty(result1) Or empty(result2) Or empty(result3) Or empty(subject1) Or empty(subject2) Or empty(subject3) Then
            MsgBox("All Filds are Required")

        Else


            If Open_db() Then


                querystr = "INSERT INTO `advance_level_result`(`Subject_Id`, `Year`, `Attemp`, `Subject_1`, `Subject_1Result`, `Subject-2`, `Subject-2Result`, `Subject_3`, `Subject-3Result`) VALUES (@sid, @year, @attem, @sub1, @subR1, @sub2, @subR2, @sub3, @subR3)"
                Dim command As New MySqlCommand(querystr, conn)


                command.Parameters.Add("@sid", MySqlDbType.Int32).Value = student_id
                command.Parameters.Add("@year", MySqlDbType.Year).Value = year
                command.Parameters.Add("@attem", MySqlDbType.VarChar).Value = attempt
                command.Parameters.Add("@sub1", MySqlDbType.VarChar).Value = subject1
                command.Parameters.Add("@subR1", MySqlDbType.VarChar).Value = result1
                command.Parameters.Add("@sub2", MySqlDbType.VarChar).Value = subject2
                command.Parameters.Add("@subR2", MySqlDbType.VarChar).Value = result2
                command.Parameters.Add("@sub3", MySqlDbType.VarChar).Value = subject3
                command.Parameters.Add("@subR3", MySqlDbType.VarChar).Value = result3

                Try
                    result = command.ExecuteNonQuery()

                    If result = True Then


                        MsgBox("Add Result")
                    Else
                        MsgBox("Not Add Result")
                    End If

                Catch ex As Exception
                    MsgBox(ex.Message)



                End Try
            Else
                MsgBox("Connection error")

            End If
        End If
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Select_Result.Show()
        Me.Hide()
    End Sub

    Private Sub bntresset_Click(sender As Object, e As EventArgs) Handles bntresset.Click
        txtsid.Text = ""
        txtresuilt3.Text = ""
        txtresult1.Text = ""
        txtresult2.Text = ""
        txtyear.Text = ""

    End Sub

    Private Sub txtresult1_TextChanged(sender As Object, e As EventArgs) Handles txtresult1.TextChanged

    End Sub

    Private Sub txtresult1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtresult1.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtresult2_TextChanged(sender As Object, e As EventArgs) Handles txtresult2.TextChanged

    End Sub

    Private Sub txtresult2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtresult2.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtresuilt3_TextChanged(sender As Object, e As EventArgs) Handles txtresuilt3.TextChanged

    End Sub

    Private Sub txtresuilt3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtresuilt3.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtsid_TextChanged(sender As Object, e As EventArgs) Handles txtsid.TextChanged

    End Sub

    Private Sub txtsid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsid.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtyear_TextChanged(sender As Object, e As EventArgs) Handles txtyear.TextChanged
    End Sub

    Private Sub txtyear_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtyear.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class