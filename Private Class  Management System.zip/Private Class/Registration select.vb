﻿Public Class Registration_select
    Private Sub bntsub_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles bntpi.Click
        parent_information.Show()
        Me.Hide()

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles bntstr.Click
        student_registration.Show()
        Me.Hide()

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles bntadds.Click
        add_subject.Show()
        Me.Hide()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles bnttr.Click
        teacher_registration.Show()
        Me.Hide()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles bntcr.Click
        class_registration.Show()
        Me.Hide()

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles bntback.Click
        manager_dashbord.Show()
        Me.Hide()

    End Sub

    Private Sub bntstaddclass_Click(sender As Object, e As EventArgs) Handles bntstaddclass.Click
        Student_enter_Class.Show()
        Me.Hide()

    End Sub
End Class