﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class teacher_details


    Private Sub bntsearch_Click(sender As Object, e As EventArgs) Handles bntsearch.Click
        If Open_db() Then
            Dim querystr As String
            querystr = "SELECT * FROM `teacher` WHERE `Teacher_Id` = '" & txtid.Text & "'"
            Dim command1 As New MySqlCommand(querystr, conn)
            Dim reader As MySqlDataReader
            Dim first_name As String
            Dim lastName As String
            Dim nic As String
            Dim phone As Integer
            Dim email As String
            Dim subject As Integer

            reader = command1.ExecuteReader
            reader.Read()
            first_name = reader.GetString(1)
            lastName = reader.GetString(2)
            nic = reader.GetString(3)
            phone = reader.GetString(4)
            email = reader.GetString(5)
            subject = reader.GetString(6)

            reader.Close()


            txtfname.Text = first_name
            txtlname.Text = lastName
            txtnic.Text = nic
            txtphone.Text = phone
            txtemail.Text = email
            txtsubject.Text = subject


        End If
    End Sub

    Private Sub Btnregster_Click(sender As Object, e As EventArgs) Handles Btnregster.Click
        Dim queryupdate, firstName, lastName, nic, email As String

        Dim teacher_id, phone, subject As Integer
        Dim result As Boolean
        teacher_id = txtid.Text
        firstName = txtfname.Text
        lastName = txtlname.Text
        nic = txtnic.Text
        phone = txtphone.Text
        email = txtemail.Text
        subject = txtsubject.Text


        If Open_db() Then
            queryupdate = "UPDATE `teacher` SET `Teacher_Id`=@tid,`First_Name`=@fname,`Last_Name`=@ln,`NIC_No`=@nic,`Phone_No`=@phone,`Email`=@email,`Subject`=@sub WHERE `Teacher_Id`=@tid"
            Dim command As New MySqlCommand(queryupdate, conn)

            command.Parameters.Add("@tid", MySqlDbType.Int32).Value = teacher_id
            command.Parameters.Add("@fname", MySqlDbType.VarChar).Value = firstName
            command.Parameters.Add("@ln", MySqlDbType.VarChar).Value = lastName
            command.Parameters.Add("@nic", MySqlDbType.VarChar).Value = nic
            command.Parameters.Add("@phone", MySqlDbType.Int32).Value = phone
            command.Parameters.Add("@email", MySqlDbType.VarChar).Value = email
            command.Parameters.Add("@sub", MySqlDbType.Int32).Value = subject

            Try
                result = command.ExecuteNonQuery()
                If result Then
                    MsgBox("successfully updated")
                    txtfname.Text = ""
                    txtlname.Text = ""
                    txtnic.Text = ""
                    txtphone.Text = ""
                    txtemail.Text = ""
                    txtsubject.Text = ""

                Else
                    MsgBox("Not Added")


                End If
            Catch ex As Exception

                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub Btnupdate_Click(sender As Object, e As EventArgs) Handles Btnupdate.Click
        Dim query As String
        Dim result As Boolean

        If Open_db() Then
            query = "DELETE FROM `teacher` WHERE `Teacher_Id` = '" & txtid.Text & "'"
            Dim command As New MySqlCommand(query, conn)
            Try
                result = command.ExecuteNonQuery()
                If result Then
                    MsgBox("successfully deleted")
                Else
                    MsgBox("Failed")
                End If
            Catch ex As Exception

            End Try
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Add_Registration.Show()
        Me.Hide()

    End Sub

    Private Sub txtid_TextChanged(sender As Object, e As EventArgs) Handles txtid.TextChanged

    End Sub

    Private Sub txtid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtid.KeyPress
        Dim pattern_no As String
        pattern_no = "^([0-9])$"
        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern_no) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtfname_TextChanged(sender As Object, e As EventArgs) Handles txtfname.TextChanged

    End Sub

    Private Sub txtfname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtfname.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtlname_TextChanged(sender As Object, e As EventArgs) Handles txtlname.TextChanged

    End Sub

    Private Sub txtlname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtlname.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtsubject_TextChanged(sender As Object, e As EventArgs) Handles txtsubject.TextChanged

    End Sub

    Private Sub txtsubject_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsubject.KeyPress
        Dim pattern As String
        pattern = "^([a-z A-Z])$"

        If Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            If Not Regex.IsMatch(e.KeyChar, pattern) Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class