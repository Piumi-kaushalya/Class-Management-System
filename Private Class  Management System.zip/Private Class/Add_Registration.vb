﻿Public Class Add_Registration
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Student_details.Show()
        Me.Hide()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        teacher_details.Show()
        Me.Hide()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        manager_dashbord.Show()
        Me.Hide()

    End Sub
End Class